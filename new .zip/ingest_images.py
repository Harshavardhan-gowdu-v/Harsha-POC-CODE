"""
ingest_images.py — Extract Images from PDFs → FAISS index

Uses PyMuPDF (fitz) ONLY — no unstructured, no detectron2, works on Windows.

Extraction strategy (better than raw xref):
  • Renders each PDF page as a high-res image (300 DPI)
  • Detects image blocks on the page using get_text("dict")
  • Crops each image block from the rendered page
  • Filters out tiny blocks (icons/decorations)
  • Embeds with CLIP (clip-ViT-B-32, 512-dim) → stored in FAISS

This approach finds ALL images including those embedded as vector graphics
that raw xref extraction misses.

Run AFTER ingest.py:
    python ingest_images.py
"""

import os
import io
import json
import base64
import logging
from pathlib import Path

import fitz          # PyMuPDF
import numpy as np
import faiss
from PIL import Image
from tqdm import tqdm

# ── Optional OCR ──────────────────────────────────────────────────────────────
try:
    import pytesseract
    pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    _OCR_AVAILABLE = True
except ImportError:
    _OCR_AVAILABLE = False
    logging.warning("pytesseract not installed — OCR disabled.")

from config import DOCS_PATH, IMAGES_PATH, FAISS_INDEX_PATH, FAISS_META_PATH
from retrieval.embeddings import get_clip_image_embedding

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
logger = logging.getLogger(__name__)

# ── Tuning constants ──────────────────────────────────────────────────────────
MIN_WIDTH  = 100       # pixels — skip images smaller than this
MIN_HEIGHT = 100
MIN_AREA   = 15000     # pixels² — skip tiny decorative elements


# ════════════════════════════════════════════════════════════════════════════
#  STEP 1 — Extract images by rendering pages at high DPI
# ════════════════════════════════════════════════════════════════════════════

def extract_images_from_pdf(pdf_path: Path) -> list:
    """
    Extract embedded images using PyMuPDF xref (Method B only).
    Method A (page render + crop) was removed because it duplicated
    the same images that xref already captures correctly.

    Deduplicates by xref ID so each unique image is extracted once.
    Returns list of dicts: { pil_image, page, source }
    """
    doc   = fitz.open(str(pdf_path))
    found = []
    seen_xrefs = set()   # deduplicate by xref — one entry per unique image

    for page_num in range(len(doc)):
        page = doc[page_num]

        for img_info in page.get_images(full=True):
            xref = img_info[0]

            # Skip if this exact image was already extracted from another page
            if xref in seen_xrefs:
                continue
            seen_xrefs.add(xref)

            try:
                base_img  = doc.extract_image(xref)
                img_bytes = base_img["image"]
                pil       = Image.open(io.BytesIO(img_bytes)).convert("RGB")
                w, h      = pil.size

                # Skip tiny images (icons, bullets, decorations)
                if w < MIN_WIDTH or h < MIN_HEIGHT or w * h < MIN_AREA:
                    logger.debug(f"  Skip tiny {w}x{h} xref={xref}")
                    continue

                found.append({
                    "pil_image": pil,
                    "page":      page_num + 1,
                    "source":    pdf_path.name,
                })
                logger.debug(f"  Extracted {w}x{h} xref={xref} page={page_num+1}")

            except Exception as e:
                logger.debug(f"  xref extract error p{page_num+1} xref={xref}: {e}")

    doc.close()
    logger.info(f"  Found {len(found)} images in {pdf_path.name}")
    return found


# ════════════════════════════════════════════════════════════════════════════
#  STEP 2 — OCR
# ════════════════════════════════════════════════════════════════════════════

def ocr_pil(pil_img: Image.Image) -> str:
    if not _OCR_AVAILABLE:
        return ""
    try:
        return pytesseract.image_to_string(pil_img).strip()
    except Exception as e:
        logger.warning(f"  OCR failed: {e}")
        return ""


# ════════════════════════════════════════════════════════════════════════════
#  STEP 3 — Save to disk + CLIP embedding
# ════════════════════════════════════════════════════════════════════════════

def save_and_embed(img_data: dict, idx: int):
    pil    = img_data["pil_image"]
    page   = img_data["page"]
    source = img_data["source"]

    stem_raw  = Path(source).stem
    stem      = "".join(c if c.isalnum() or c in "-_" else "_" for c in stem_raw)
    save_name = f"{stem}_p{page}_img{idx}.png"
    save_path = os.path.join(IMAGES_PATH, save_name)

    try:
        pil.save(save_path, "PNG")
    except Exception as e:
        logger.warning(f"  Could not save {save_name}: {e}")
        return None, None

    emb = get_clip_image_embedding(save_path)
    if emb is None or float(emb.sum()) == 0.0:
        logger.warning(f"  Zero CLIP embedding — skipping {save_name}")
        if os.path.exists(save_path):
            os.remove(save_path)
        return None, None

    ocr_text = ocr_pil(pil)
    keywords = _extract_keywords(ocr_text)

    # Also store base64 in metadata so retriever doesn't need to re-read disk
    buf = io.BytesIO()
    pil.thumbnail((600, 600))
    pil.save(buf, format="JPEG", quality=75)
    b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

    metadata = {
        "image_path":     save_path,
        "image_base64":   b64,        # pre-cached for fast retrieval
        "page":           int(page),
        "source":         source,
        "caption":        "",
        "image_text":     ocr_text,
        "page_context":   "",
        "image_keywords": keywords,
    }
    return emb, metadata


# ════════════════════════════════════════════════════════════════════════════
#  STEP 4 — Build FAISS index
# ════════════════════════════════════════════════════════════════════════════

def build_faiss_index(all_embeddings, all_metadata):
    if not all_embeddings:
        logger.warning("No embeddings to index.")
        return

    matrix = np.vstack(all_embeddings).astype(np.float32)
    inner  = faiss.IndexFlatL2(512)
    index  = faiss.IndexIDMap2(inner)
    ids    = np.arange(len(all_embeddings), dtype=np.int64)
    index.add_with_ids(matrix, ids)

    faiss.write_index(index, FAISS_INDEX_PATH)
    logger.info(f"  FAISS index saved  → {FAISS_INDEX_PATH}")

    with open(FAISS_META_PATH, "w") as f:
        json.dump(all_metadata, f, indent=2, ensure_ascii=False)
    logger.info(f"  Metadata saved     → {FAISS_META_PATH}")


# ════════════════════════════════════════════════════════════════════════════
#  MAIN
# ════════════════════════════════════════════════════════════════════════════

def ingest_images_all():
    docs_folder = Path(DOCS_PATH)
    pdf_files   = sorted(docs_folder.glob("*.pdf"))

    if not pdf_files:
        print(f"\nNo PDFs found in: {docs_folder.resolve()}\n")
        return

    os.makedirs(IMAGES_PATH, exist_ok=True)

    # Load existing index (incremental)
    existing_paths = set()
    all_metadata   = []
    all_embeddings = []

    if Path(FAISS_META_PATH).exists():
        try:
            with open(FAISS_META_PATH) as f:
                all_metadata = json.load(f)
            existing_paths = {m["image_path"] for m in all_metadata}
            logger.info(f"Loaded {len(all_metadata)} existing image records.")
        except Exception:
            all_metadata = []

    if Path(FAISS_INDEX_PATH).exists() and all_metadata:
        try:
            index = faiss.read_index(FAISS_INDEX_PATH)
            for i in range(index.ntotal):
                vec = np.zeros(512, dtype=np.float32)
                index.reconstruct(i, vec)
                all_embeddings.append(vec)
            logger.info(f"Loaded {len(all_embeddings)} existing FAISS vectors.")
        except Exception as e:
            logger.warning(f"Could not load FAISS index: {e} — rebuilding.")
            all_embeddings = []
            all_metadata   = []
            existing_paths = set()

    print(f"\n📁  Found {len(pdf_files)} PDF(s)\n")
    total_new = 0

    for pdf_path in pdf_files:
        print(f"{'─'*60}")
        print(f"📄  {pdf_path.name}")

        raw_images = extract_images_from_pdf(pdf_path)

        if not raw_images:
            print(f"  ⚠️  No images found — skipping.")
            continue

        pdf_new = 0
        for i, img_data in enumerate(tqdm(raw_images, desc="  Embedding", unit="img")):
            stem_raw  = Path(img_data["source"]).stem
            stem      = "".join(c if c.isalnum() or c in "-_" else "_" for c in stem_raw)
            save_name = f"{stem}_p{img_data['page']}_img{i}.png"
            save_path = os.path.join(IMAGES_PATH, save_name)
            if save_path in existing_paths:
                continue

            emb, meta = save_and_embed(img_data, i)
            if emb is None:
                continue

            all_embeddings.append(emb)
            all_metadata.append(meta)
            existing_paths.add(save_path)
            pdf_new += 1

        print(f"  ✅  {pdf_new} new images indexed from {pdf_path.name}")
        total_new += pdf_new

    if total_new == 0:
        print("\n✅  No new images to index.")
        return

    print(f"\n🔢  Building FAISS index ({len(all_embeddings)} total images) ...")
    build_faiss_index(all_embeddings, all_metadata)

    print(f"\n{'═'*60}")
    print(f"🎉  Image ingestion complete!")
    print(f"    New images indexed : {total_new}")
    print(f"    Total in FAISS     : {len(all_metadata)}")
    print(f"{'═'*60}\n")


def _extract_keywords(text: str, top_n: int = 20) -> list:
    stop = {"with","from","that","this","have","been","were","they","their",
            "will","also","more","than","each","into","which","when","then",
            "over","both","only","such","used","using"}
    words, seen = [], set()
    for w in text.split():
        wc = w.strip(".,;:\"'()-[]").strip()
        wl = wc.lower()
        if len(wl) > 3 and wl not in stop and wl not in seen:
            words.append(wc)
            seen.add(wl)
        if len(words) >= top_n:
            break
    return words


if __name__ == "__main__":
    ingest_images_all()