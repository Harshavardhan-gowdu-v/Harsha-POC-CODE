"""
ingest.py — Extract Text + Tables from PDFs → ChromaDB

Run this ONCE (or whenever you add new PDFs):
    python ingest.py

What it does:
  1. Finds all PDFs in DOCS_PATH
  2. Extracts text per page  (PyMuPDF)
  3. Extracts tables          (pdfplumber → plain text rows)
  4. Chunks text with overlap
  5. Embeds each chunk        (all-MiniLM-L6-v2, 384-dim, local)
  6. Stores in ChromaDB        (persistent on disk)

Skips PDFs that were already ingested (incremental).
"""

import os
import logging
from pathlib import Path

import fitz          # PyMuPDF
import pdfplumber
from tqdm import tqdm
import chromadb

from config import DOCS_PATH, CHROMA_PATH, CHUNK_SIZE, CHUNK_OVERLAP
from retrieval.embeddings import get_text_embedding

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
logger = logging.getLogger(__name__)


# ════════════════════════════════════════════════════════════════════════════
#  CHROMADB
# ════════════════════════════════════════════════════════════════════════════

def get_collection():
    """Return (or create) the persistent ChromaDB 'documents' collection."""
    os.makedirs(CHROMA_PATH, exist_ok=True)
    client = chromadb.PersistentClient(path=CHROMA_PATH)
    try:
        col = client.get_collection("documents")
    except Exception:
        col = client.create_collection(
            "documents",
            metadata={"hnsw:space": "cosine"}
        )
    return col


def store_batch(col, ids, embeddings, documents, metadatas):
    """Upsert one batch into ChromaDB. Returns count stored."""
    if not ids:
        return 0
    try:
        col.upsert(ids=ids, embeddings=embeddings,
                   documents=documents, metadatas=metadatas)
        return len(ids)
    except Exception as e:
        logger.error(f"  store_batch error: {e}")
        return 0


# ════════════════════════════════════════════════════════════════════════════
#  TEXT EXTRACTION  (PyMuPDF)
# ════════════════════════════════════════════════════════════════════════════

def extract_text_pages(pdf_path: Path) -> list[dict]:
    """
    Return one dict per page that has meaningful text:
      { text, page_num, source }
    """
    pages = []
    try:
        doc = fitz.open(str(pdf_path))
        for i, page in enumerate(doc):
            text = page.get_text("text").strip()
            if len(text) > 50:
                pages.append({
                    "text":     text,
                    "page_num": i + 1,
                    "source":   pdf_path.name,
                })
        doc.close()
        logger.info(f"  text pages: {len(pages)}")
    except Exception as e:
        logger.error(f"  extract_text error: {e}")
    return pages


# ════════════════════════════════════════════════════════════════════════════
#  TABLE EXTRACTION  (pdfplumber)
# ════════════════════════════════════════════════════════════════════════════

def extract_tables(pdf_path: Path) -> list[dict]:
    """
    Return one dict per table found:
      { content, page, source, type="table" }
    Table content is formatted as "col1 | col2 | col3" rows.
    """
    table_chunks = []
    try:
        with pdfplumber.open(str(pdf_path)) as pdf:
            for i, page in enumerate(pdf.pages):
                try:
                    tables = page.extract_tables()
                    if not tables:
                        continue
                    for t_idx, table in enumerate(tables):
                        if not table or len(table) < 2:
                            continue
                        rows = []
                        for row in table:
                            cleaned = [str(c).strip() if c else "" for c in row]
                            rows.append(" | ".join(cleaned))
                        table_text = "\n".join(rows).strip()
                        if len(table_text) < 20:
                            continue
                        table_chunks.append({
                            "content": f"[TABLE — page {i+1}]\n{table_text}",
                            "page":    i + 1,
                            "source":  pdf_path.name,
                            "type":    "table",
                        })
                except Exception as e:
                    logger.warning(f"  table page {i+1} error: {e}")
        logger.info(f"  tables found: {len(table_chunks)}")
    except Exception as e:
        logger.error(f"  extract_tables error: {e}")
    return table_chunks


# ════════════════════════════════════════════════════════════════════════════
#  CHUNKING  (word-level with overlap)
# ════════════════════════════════════════════════════════════════════════════

def chunk_page(page: dict) -> list[dict]:
    """Split a page's text into overlapping word-level chunks."""
    words = page["text"].split()
    if not words:
        return []
    step = max(1, CHUNK_SIZE - CHUNK_OVERLAP)
    chunks = []
    for i in range(0, len(words), step):
        word_slice = words[i : i + CHUNK_SIZE]
        if len(word_slice) < 15:          # skip tiny trailing fragments
            continue
        chunks.append({
            "content": " ".join(word_slice),
            "page":    page["page_num"],
            "source":  page["source"],
            "type":    "text",
        })
    return chunks


# ════════════════════════════════════════════════════════════════════════════
#  MAIN
# ════════════════════════════════════════════════════════════════════════════

def ingest_all():
    docs_folder = Path(DOCS_PATH)
    pdf_files   = sorted(docs_folder.glob("*.pdf"))

    if not pdf_files:
        print(f"\n❌  No PDFs found in: {docs_folder.resolve()}")
        print("    Add PDF files there and re-run.\n")
        return

    print(f"\n📁  Found {len(pdf_files)} PDF(s):")
    for f in pdf_files:
        print(f"    • {f.name}")

    # ── Skip already-ingested PDFs ────────────────────────────
    col = get_collection()
    try:
        existing  = col.get(limit=100_000)
        ingested  = {m["source"] for m in existing.get("metadatas", [])}
    except Exception:
        ingested = set()

    new_pdfs = [f for f in pdf_files if f.name not in ingested]
    if not new_pdfs:
        print(f"\n✅  All PDFs already ingested ({len(ingested)} sources in ChromaDB).")
        print(f"    Total chunks: {col.count()}\n")
        return

    print(f"\n🆕  New PDFs to process: {len(new_pdfs)}")

    total_stored = 0
    BATCH = 32

    for pdf_path in new_pdfs:
        print(f"\n{'─'*60}")
        print(f"📄  {pdf_path.name}")
        print('─'*60)

        # Extract
        pages       = extract_text_pages(pdf_path)
        text_chunks = [c for p in pages for c in chunk_page(p)]
        table_chunks = extract_tables(pdf_path)

        all_chunks = text_chunks + table_chunks
        print(f"  text chunks : {len(text_chunks)}")
        print(f"  table chunks: {len(table_chunks)}")
        print(f"  total       : {len(all_chunks)}")

        if not all_chunks:
            print("  ⚠️  Nothing extracted — skipping.")
            continue

        # Embed + store in batches
        stored = 0
        for i in tqdm(range(0, len(all_chunks), BATCH),
                      desc="  Embedding & storing", unit="batch"):
            batch = all_chunks[i : i + BATCH]
            ids, embs, docs, metas = [], [], [], []

            for j, chunk in enumerate(batch):
                emb = get_text_embedding(chunk["content"])
                if emb is None or emb.sum() == 0:
                    continue
                chunk_id = (
                    f"{chunk['type']}_{chunk['source'].replace('.pdf','')}"
                    f"_p{chunk['page']}_{i+j}"
                )
                ids.append(chunk_id)
                embs.append(emb.tolist())
                docs.append(chunk["content"])
                metas.append({
                    "page":   int(chunk["page"]),
                    "type":   chunk["type"],
                    "source": chunk["source"],
                })

            stored += store_batch(col, ids, embs, docs, metas)

        print(f"  ✅  Stored: {stored} chunks")
        total_stored += stored

    print(f"\n{'═'*60}")
    print(f"🎉  Ingestion complete!")
    print(f"    New chunks added : {total_stored}")
    print(f"    Total in ChromaDB: {col.count()}")
    print(f"{'═'*60}\n")


if __name__ == "__main__":
    ingest_all()
