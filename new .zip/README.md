# Multimodal RAG — ECS FINAL

## Structure
ECS_FINAL/
├── app/
│   ├── main.py        ← FastAPI OpenAI-compatible server
│   ├── llm.py         ← llava (vision) + llama3.2 (text) dual model
│   └── prompts.py     ← RAG prompt builder
├── retrieval/
│   ├── embeddings.py  ← all-MiniLM-L6-v2 + CLIP (local, no API)
│   └── retriever.py   ← text (ChromaDB) + image (FAISS, 1-of-3 filter)
├── data/
│   ├── input_pdfs/    ← PUT YOUR PDFs HERE
│   ├── images/        ← auto-created
│   └── chroma_db/     ← auto-created
├── ingest.py          ← text + tables → ChromaDB
├── ingest_images.py   ← images → FAISS
├── config.py
└── run.py

## Setup
1. pip install -r requirements.txt
2. ollama pull llama3.2
3. ollama pull llava
4. Put PDFs in data/input_pdfs/
5. python ingest.py
6. python ingest_images.py
7. python run.py

## Connect OpenWebUI
URL  : http://<your-ip>:8100/v1   (shown when run.py starts)
Key  : rag-key
Model: rag-model

## Image Condition (1-of-3)
Image is shown if ANY ONE passes:
  C1 — CLIP visual similarity score < 1.2
  C2 — Image page within ±1 of text answer pages
  C3 — Caption/OCR contains 25%+ of query keywords
