"""
app/prompts.py — RAG prompt builder

Image description priority: caption > ocr_text (no LLaVA dependency).
"""


def build_rag_prompt(query: str, text_chunks: list, image_chunks: list = None) -> str:
    image_chunks = image_chunks or []

    # ── Text / table context ──────────────────────────────────────────────────
    context_parts = []
    for c in text_chunks:
        tag = f"[{c['type'].upper()} | {c['source']} | Page {c['page']}]"
        context_parts.append(f"{tag}\n{c['content']}")
    context = "\n\n---\n\n".join(context_parts)[:5000]

    # ── Image context (caption > ocr_text — no LLaVA) ────────────────────────
    image_section = ""
    if image_chunks:
        parts = []
        for i, img in enumerate(image_chunks, 1):
            lines = [f"Image {i}: {img['source']}, Page {img['page']}"]

            # Show which conditions passed (C1/C2/C3) for LLM context
            conditions = img.get("conditions", [])
            if conditions:
                lines.append(f"  Match signals: {', '.join(conditions)}")

            if img.get("caption"):
                lines.append(f"  Caption: {img['caption']}")

            # ocr_text fallback (no llava_description in new retriever)
            if img.get("ocr_text"):
                lines.append(f"  OCR text: {img['ocr_text'][:200]}")

            parts.append("\n".join(lines))

        image_section = (
            "\n\n=== RELEVANT FIGURES ===\n"
            + "\n\n".join(parts)
            + "\n\nWhen answering, reference figures by number, e.g. 'See Image 1 below'."
        )

    # ── Final prompt ──────────────────────────────────────────────────────────
    prompt = f"""You are a precise document assistant. Answer ONLY using the context below.

ANSWER FORMAT (use plain text paragraphs, NO markdown tables, NO code blocks):
1. **Definition** — 1-2 sentence definition
2. **Explanation** — Detail from the document with page citations like (Page N)
3. **Sub-topics** — Related sub-concepts from the document
4. **Figures** — If figures were found, say "See Image 1 below" (do NOT describe the image in detail)
5. **Summary** — One-sentence takeaway
6. **Source** — Filename and page range

STRICT RULES:
- Use ONLY the provided context. No outside knowledge.
- Do NOT generate markdown tables or code blocks.
- Do NOT embed or describe image URLs. Just reference figures by number.
- If the answer is not in the context, reply: "Not found in documents."

=== CONTEXT ===
{context}{image_section}
=== END CONTEXT ===

Question: {query}

Answer:"""

    return prompt
