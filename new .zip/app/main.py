"""
app/main.py — OpenAI-compatible FastAPI server for Open WebUI

Connect Open WebUI:
  URL : http://<your-lan-ip>:8100/v1
  Key : rag-key  (anything)
  Model: rag-model
"""
import json, time, uuid, os, logging

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional

from config import IMAGES_PATH
from app.llm import generate_answer, generate_answer_stream

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
logger = logging.getLogger(__name__)

app = FastAPI(title="Multimodal RAG", version="3.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

os.makedirs(IMAGES_PATH, exist_ok=True)
app.mount("/images", StaticFiles(directory=IMAGES_PATH), name="images")


class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    model: str
    messages: List[Message]
    stream: Optional[bool] = False
    temperature: Optional[float] = 0.1


@app.get("/v1/models")
def list_models():
    return {"object": "list", "data": [{
        "id": "rag-model", "object": "model",
        "owned_by": "local-rag", "created": 1700000000,
    }]}


@app.post("/v1/chat/completions")
async def chat(req: ChatRequest):
    user_msgs = [m for m in req.messages if m.role == "user"]
    if not user_msgs:
        raise HTTPException(400, "No user message")

    question = user_msgs[-1].content
    req_id   = f"chatcmpl-{uuid.uuid4().hex[:8]}"
    created  = int(time.time())

    if req.stream:
        def streamer():
            try:
                for token in generate_answer_stream(question):
                    data = {
                        "id": req_id, "object": "chat.completion.chunk",
                        "created": created, "model": "rag-model",
                        "choices": [{"index": 0,
                                     "delta": {"content": token},
                                     "finish_reason": None}],
                    }
                    yield f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
            except Exception as e:
                yield f"data: {json.dumps({'choices':[{'delta':{'content':f'[Error:{e}]'},'finish_reason':None}]})}\n\n"
            finally:
                yield f"data: {json.dumps({'choices':[{'finish_reason':'stop'}]})}\n\n"
                yield "data: [DONE]\n\n"

        return StreamingResponse(
            streamer(), media_type="text/event-stream",
            headers={
                "X-Accel-Buffering": "no",
                "Cache-Control": "no-cache",
                "Access-Control-Allow-Origin": "*",
            },
        )

    try:
        answer = generate_answer(question)
    except Exception as e:
        answer = f"Error: {e}"

    return {
        "id": req_id, "object": "chat.completion",
        "created": created, "model": "rag-model",
        "choices": [{"index": 0,
                     "message": {"role": "assistant", "content": answer},
                     "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
    }


@app.get("/health")
def health():
    try:
        import chromadb
        from config import CHROMA_PATH
        client = chromadb.PersistentClient(path=CHROMA_PATH)
        tc = client.get_collection("documents").count()
    except Exception:
        tc = 0
    try:
        import json as _json
        from config import FAISS_META_PATH
        ic = len(_json.load(open(FAISS_META_PATH)))
    except Exception:
        ic = 0
    return {"status": "ok", "text_chunks": tc, "image_count": ic}


@app.get("/v1/health")
def v1_health():
    return {"status": "ok"}


@app.get("/")
def root():
    from config import IMAGE_HOST, API_PORT
    return {
        "status": "running",
        "openwebui_url": f"http://{IMAGE_HOST}:{API_PORT}/v1",
    }
