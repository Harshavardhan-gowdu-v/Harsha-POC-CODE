"""
app/llm.py — RAG answer generation with inline image rendering

Flow:
  1. full_retrieve() → returns text chunks + image chunks
                       (images validated by mandatory gate + C1/C2/C3 conditions)
  2. Build prompt with text context + image captions/OCR
  3. llama3.2 generates the text answer
  4. Append inline base64 images as one block to the response

NOTE: LLaVA has been removed. Image relevance is determined by CLIP + C1/C2/C3
conditions in retriever.py. No Ollama vision calls happen here.
Image description in prompt uses caption > ocr_text from ingestion metadata.
"""
import time
import logging
import ollama

from config import ANSWER_MODEL
from app.prompts import build_rag_prompt
from retrieval.retriever import full_retrieve

logger = logging.getLogger(__name__)


# ════════════════════════════════════════════════════════════════════════════
#  IMAGE → MARKDOWN  (inline base64 for OpenWebUI)
# ════════════════════════════════════════════════════════════════════════════

def _img_to_markdown(img: dict, number: int) -> str:
    """
    Build inline base64 markdown image block.
    Uses caption > ocr_text from ingestion metadata (no LLaVA).
    Also shows which conditions (C1/C2/C3) passed for transparency.
    """
    b64        = img.get("image_base64", "")
    page       = img.get("page", "?")
    source     = img.get("source", "")
    caption    = img.get("caption", "")
    ocr_text   = img.get("ocr_text", "")
    conditions = img.get("conditions", [])

    if not b64:
        return f"\n\n*[Image {number}: not available]*\n"

    # Best available description — caption first, OCR fallback
    desc = caption or ocr_text or ""
    label = desc[:100] if desc else f"Figure from {source}, Page {page}"

    # Conditions badge for transparency
    cond_badge = f" `[{', '.join(conditions)}]`" if conditions else ""

    return (
        f"\n\n**Image {number}**{cond_badge} — *{source}, Page {page}*"
        + (f"\n*{caption[:120]}*" if caption else "")
        + f"\n\n![{label}](data:image/jpeg;base64,{b64})\n"
    )


def _build_image_section(image_chunks: list) -> str:
    """Build full image section — yielded as ONE token to keep base64 intact."""
    if not image_chunks:
        return ""
    parts = ["\n\n---\n### Relevant Figures\n"]
    for i, img in enumerate(image_chunks, 1):
        parts.append(_img_to_markdown(img, i))
    return "".join(parts)


# ════════════════════════════════════════════════════════════════════════════
#  NON-STREAMING
# ════════════════════════════════════════════════════════════════════════════

def generate_answer(query: str) -> str:
    t0 = time.time()

    text_chunks, image_chunks = full_retrieve(query)
    t_ret = time.time() - t0

    if not text_chunks and not image_chunks:
        return "No relevant data found in the ingested documents."

    prompt = build_rag_prompt(query, text_chunks, image_chunks)

    t_llm = time.time()
    try:
        response = ollama.chat(
            model=ANSWER_MODEL,
            messages=[{"role": "user", "content": prompt}],
            options={"num_ctx": 4096, "num_predict": 1024},
            keep_alive=0,
        )
        answer = response["message"]["content"]
    except Exception as e:
        return f"LLM error: {e}\n\nMake sure Ollama is running: `ollama serve`"
    t_llm_done = time.time() - t_llm

    # Append images as ONE block (keeps base64 URI intact)
    answer += _build_image_section(image_chunks)

    total = time.time() - t0
    answer += (
        f"\n\n---\n*Retrieval: {t_ret:.1f}s | LLM: {t_llm_done:.1f}s | "
        f"Total: {total:.1f}s | Model: {ANSWER_MODEL} | "
        f"Images: {len(image_chunks)}*"
    )
    return answer


# ════════════════════════════════════════════════════════════════════════════
#  STREAMING
# ════════════════════════════════════════════════════════════════════════════

def generate_answer_stream(query: str):
    t0 = time.time()

    text_chunks, image_chunks = full_retrieve(query)
    t_ret = time.time() - t0

    if not text_chunks and not image_chunks:
        yield "No relevant data found in the ingested documents."
        return

    if image_chunks:
        cond_summary = ", ".join(
            "/".join(img.get("conditions", [])) for img in image_chunks
        )
        yield (
            f"*{len(image_chunks)} relevant figure(s) found "
            f"[{cond_summary}] — generating answer...*\n\n"
        )

    prompt = build_rag_prompt(query, text_chunks, image_chunks)

    t_llm = time.time()
    try:
        for chunk in ollama.chat(
            model=ANSWER_MODEL,
            messages=[{"role": "user", "content": prompt}],
            stream=True,
            options={"num_ctx": 4096, "num_predict": 1024},
            keep_alive=0,
        ):
            token = chunk["message"]["content"]
            if token:
                yield token
    except Exception as e:
        yield f"\n\n[LLM Error: {e}]"
        return
    t_llm_done = time.time() - t_llm

    # Yield entire image section as ONE token
    # Critical: base64 URI must not be split across SSE frames
    img_section = _build_image_section(image_chunks)
    if img_section:
        yield img_section

    total = time.time() - t0
    yield (
        f"\n\n---\n*Retrieval: {t_ret:.1f}s | LLM: {t_llm_done:.1f}s | "
        f"Total: {total:.1f}s | Model: {ANSWER_MODEL} | "
        f"Images: {len(image_chunks)}*"
    )
