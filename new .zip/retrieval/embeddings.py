"""
retrieval/embeddings.py — Local multimodal embeddings (no API keys needed)

Two embedding spaces:
  ① all-MiniLM-L6-v2   (384-dim)  — text & table search via ChromaDB
  ② clip-ViT-B-32       (512-dim)  — image search via FAISS
      text query → 512-dim  ↔  image → 512-dim  (same space = cross-modal search)
"""

import warnings
warnings.filterwarnings("ignore")

import logging
import numpy as np
import torch
from pathlib import Path
from PIL import Image
from sentence_transformers import SentenceTransformer

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── Load models once at import time ─────────────────────────────────────────

logger.info("[embeddings] Loading text model  (all-MiniLM-L6-v2) ...")
_text_model = SentenceTransformer("all-MiniLM-L6-v2")
logger.info("[embeddings] ✅ Text model ready  (384-dim)")

logger.info("[embeddings] Loading CLIP model  (clip-ViT-B-32) ...")
_clip_model = SentenceTransformer("clip-ViT-B-32")
logger.info("[embeddings] ✅ CLIP model ready  (512-dim)")

_DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
logger.info(f"[embeddings] Device: {_DEVICE.upper()}")


# ════════════════════════════════════════════════════════════════════════════
# ①  TEXT EMBEDDING  (384-dim)  — used for text / table chunks
# ════════════════════════════════════════════════════════════════════════════

def get_text_embedding(text: str) -> np.ndarray:
    """
    Embed text/table content for ChromaDB storage & query.
    Returns numpy float32 array of shape (384,).
    """
    text = str(text).strip()[:512]
    if not text:
        return np.zeros(384, dtype=np.float32)
    try:
        emb = _text_model.encode(text, convert_to_numpy=True, normalize_embeddings=True)
        return emb.astype(np.float32)
    except Exception as e:
        logger.error(f"[embeddings] text embed error: {e}")
        return np.zeros(384, dtype=np.float32)


# ════════════════════════════════════════════════════════════════════════════
# ②a  CLIP TEXT EMBEDDING  (512-dim)  — query → image search
# ════════════════════════════════════════════════════════════════════════════

def get_clip_text_embedding(text: str) -> np.ndarray:
    """
    Embed a text query into the CLIP 512-dim space so it can be
    compared against CLIP image embeddings stored in FAISS.
    Returns numpy float32 array of shape (512,).
    """
    text = str(text).strip()[:512]
    if not text:
        return np.zeros(512, dtype=np.float32)
    try:
        emb = _clip_model.encode(text, convert_to_numpy=True, normalize_embeddings=True)
        return emb.astype(np.float32)
    except Exception as e:
        logger.error(f"[embeddings] CLIP text embed error: {e}")
        return np.zeros(512, dtype=np.float32)


# ════════════════════════════════════════════════════════════════════════════
# ②b  CLIP IMAGE EMBEDDING  (512-dim)  — ingest images into FAISS
# ════════════════════════════════════════════════════════════════════════════

def get_clip_image_embedding(image_path: str) -> np.ndarray:
    """
    Embed an image file into the CLIP 512-dim space for FAISS storage.
    Called during ingestion (ingest_images.py).
    Returns numpy float32 array of shape (512,).
    """
    if not Path(image_path).exists():
        logger.error(f"[embeddings] Image not found: {image_path}")
        return np.zeros(512, dtype=np.float32)
    try:
        image = Image.open(image_path).convert("RGB")
        emb = _clip_model.encode(image, convert_to_numpy=True, normalize_embeddings=True)
        return emb.astype(np.float32)
    except Exception as e:
        logger.error(f"[embeddings] CLIP image embed error ({image_path}): {e}")
        return np.zeros(512, dtype=np.float32)


# ── Backward-compat aliases ──────────────────────────────────────────────────

get_embedding               = get_text_embedding          # legacy alias
get_text_to_image_embedding = get_clip_text_embedding     # legacy alias
get_image_embedding         = get_clip_image_embedding    # legacy alias


# ── Quick self-test ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n" + "="*60)
    print("EMBEDDING SELF-TEST")
    print("="*60)

    t = get_text_embedding("What is transformer architecture?")
    print(f"\n✅ Text embedding    dim={len(t)}  dtype={t.dtype}")

    c = get_clip_text_embedding("scaled dot-product attention diagram")
    print(f"✅ CLIP text embed   dim={len(c)}  dtype={c.dtype}")

    print("\n" + "="*60 + "\n")
