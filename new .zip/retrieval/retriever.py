"""
retrieval/retriever.py — Multimodal Retrieval Pipeline (No LLaVA)

TEXT/TABLE:
  Stage 1 — ChromaDB cosine search (all-MiniLM-L6-v2, 384-dim)
  Stage 2 — CrossEncoder reranking

IMAGE — 1-of-3 Condition System (no LLaVA required):
  MANDATORY GATE (ALWAYS applied — image dropped if this fails):
    ✅  Same PDF source as text answer
    ✅  Image page within ±3 of text answer pages

  AFTER mandatory gate, ANY 1 of 3 conditions = image is retrieved:
    C1 — CLIP visual similarity   : CLIP L2 distance < threshold
    C2 — Page proximity ±3        : image page within ±3 of text pages
    C3 — Caption/OCR keyword match: ≥25% of query words found in caption+OCR

  Final rule (exact specification):
    (C1 OR C2 OR C3)  AND  same_pdf  AND  |img_page - text_page| <= 3
"""

import os
import io
import json
import base64
import logging
from pathlib import Path
from typing import List, Dict, Tuple

import numpy as np
from sentence_transformers import CrossEncoder, SentenceTransformer
from PIL import Image

from config import (
    CHROMA_PATH, RERANKER_MODEL, IMAGES_PATH,
    TOP_K_RETRIEVE, TOP_K_RERANK, TOP_K_IMAGES,
    CLIP_DISTANCE_THRESHOLD, KEYWORD_MATCH_RATIO,
    PAGE_WINDOW, IMG_MAX_PX, IMG_QUALITY,
    FAISS_INDEX_PATH, FAISS_META_PATH,
)
from retrieval.embeddings import get_text_embedding, get_clip_text_embedding

try:
    import chromadb
except ImportError:
    raise ImportError("pip install chromadb")

try:
    import faiss
except ImportError:
    raise ImportError("pip install faiss-cpu")

import warnings
warnings.filterwarnings("ignore")

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
logger = logging.getLogger(__name__)

# Page proximity window — used in MANDATORY gate AND in C2


# ════════════════════════════════════════════════════════════════════════════
#  LOAD MODELS ONCE
# ════════════════════════════════════════════════════════════════════════════

logger.info(f"[retriever] Loading reranker: {RERANKER_MODEL}")
try:
    _reranker = CrossEncoder(RERANKER_MODEL)
    logger.info("[retriever] ✅ CrossEncoder ready")
except Exception as e:
    logger.error(f"[retriever] Reranker load failed: {e}")
    _reranker = None

logger.info("[retriever] Loading caption similarity model (all-MiniLM-L6-v2)...")
try:
    _caption_model = SentenceTransformer("all-MiniLM-L6-v2")
    logger.info("[retriever] ✅ Caption model ready")
except Exception as e:
    logger.error(f"[retriever] Caption model failed: {e}")
    _caption_model = None


# ════════════════════════════════════════════════════════════════════════════
#  CHROMADB — TEXT + TABLE RETRIEVAL
# ════════════════════════════════════════════════════════════════════════════

def _get_text_collection():
    os.makedirs(CHROMA_PATH, exist_ok=True)
    client = chromadb.PersistentClient(path=CHROMA_PATH)
    try:
        return client.get_collection("documents")
    except Exception:
        return client.create_collection(
            "documents", metadata={"hnsw:space": "cosine"}
        )


def retrieve_text(query: str, top_k: int = TOP_K_RETRIEVE) -> List[Dict]:
    try:
        col   = _get_text_collection()
        count = col.count()
        if count == 0:
            return []
        q_emb   = get_text_embedding(query)
        results = col.query(
            query_embeddings=[q_emb.tolist()],
            n_results=min(top_k, count),
            include=["documents", "metadatas", "distances"],
        )
        docs = []
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            docs.append({
                "content":  doc,
                "page":     meta.get("page", 0),
                "type":     meta.get("type", "text"),
                "source":   meta.get("source", ""),
                "distance": float(dist),
            })
        return docs
    except Exception as e:
        logger.error(f"[retriever] retrieve_text error: {e}")
        return []


def rerank_text(query: str, docs: List[Dict],
                top_k: int = TOP_K_RERANK) -> List[Dict]:
    if not docs:
        return []
    if _reranker is None:
        return sorted(docs, key=lambda d: d["distance"])[:top_k]
    try:
        pairs  = [[query, d["content"]] for d in docs]
        scores = _reranker.predict(pairs)
        ranked = sorted(zip(docs, scores), key=lambda x: x[1], reverse=True)
        return [d for d, _ in ranked[:top_k]]
    except Exception as e:
        logger.error(f"[retriever] rerank error: {e}")
        return docs[:top_k]


# ════════════════════════════════════════════════════════════════════════════
#  IMAGE COMPRESSION
# ════════════════════════════════════════════════════════════════════════════

def _compress_to_b64(img_path: str = "", b64_input: str = "") -> str:
    try:
        pil = None
        if img_path and os.path.exists(img_path):
            try:
                pil = Image.open(img_path).convert("RGB")
            except Exception:
                pass

        if pil is None and img_path:
            fname     = Path(img_path.replace("\\", "/")).name
            candidate = os.path.join(IMAGES_PATH, fname)
            if os.path.exists(candidate):
                try:
                    pil = Image.open(candidate).convert("RGB")
                    logger.info(f"  Resolved -> {candidate}")
                except Exception:
                    pass

        if pil is None and b64_input:
            try:
                raw = base64.b64decode(b64_input)
                pil = Image.open(io.BytesIO(raw)).convert("RGB")
            except Exception:
                pass

        if pil is None:
            return ""

        pil.thumbnail((IMG_MAX_PX, IMG_MAX_PX))
        buf = io.BytesIO()
        pil.save(buf, format="JPEG", quality=IMG_QUALITY, optimize=True)
        b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
        logger.info(f"  Image -> {len(b64)*3/4/1024:.1f} KB")
        return b64
    except Exception as e:
        logger.warning(f"  Compress failed: {e}")
        return ""


# ════════════════════════════════════════════════════════════════════════════
#  MANDATORY GATE
# ════════════════════════════════════════════════════════════════════════════

def _mandatory_gate(
    img_page: int,
    img_source: str,
    text_pages: set,
    text_sources: set,
) -> Tuple[bool, str]:
    """
    MANDATORY gate — ALL images must pass this before C1/C2/C3 are checked.

    Rules (both must be satisfied):
      1. img_source  in  text_sources            (same PDF)
      2. img_page is within +-PAGE_WINDOW         (page proximity)
         of at least one text answer page

    Returns (passed: bool, reason: str)
    """
    # Rule 1 — same PDF
    if text_sources and img_source not in text_sources:
        return False, f"source mismatch: image='{img_source}' not in {text_sources}"

    # Rule 2 — page within +-PAGE_WINDOW of any text page
    if text_pages:
        nearby = set(range(img_page - PAGE_WINDOW, img_page + PAGE_WINDOW + 1))
        if not nearby.intersection(text_pages):
            return False, (
                f"page {img_page} not within +-{PAGE_WINDOW} "
                f"of text pages {sorted(text_pages)}"
            )
    else:
        return False, "no text pages available"

    return True, "ok"


# ════════════════════════════════════════════════════════════════════════════
#  C1 / C2 / C3 CONDITION CHECKS
# ════════════════════════════════════════════════════════════════════════════

def _check_c1_clip(dist: float) -> bool:
    """C1 — CLIP visual similarity: L2 distance < threshold."""
    return dist <= CLIP_DISTANCE_THRESHOLD


def _check_c2_page_proximity(img_page: int, text_pages: set) -> bool:
    """
    C2 — Page proximity +-PAGE_WINDOW to text retrieval pages.
    Mirrors the mandatory gate window for explicit logging.
    """
    if not text_pages:
        return False
    nearby = set(range(img_page - PAGE_WINDOW, img_page + PAGE_WINDOW + 1))
    return bool(nearby.intersection(text_pages))


def _check_c3_keyword(query: str, caption: str, ocr_text: str) -> bool:
    """
    C3 — Caption/OCR keyword match with query.
    At least 25% of meaningful query words (length > 3) must appear
    in the combined caption + OCR text.
    """
    combined    = f"{caption} {ocr_text}".lower()
    query_words = [w for w in query.lower().split() if len(w) > 3]
    if not query_words or not combined.strip() or len(combined) < 10:
        return False
    matched = sum(1 for w in query_words if w in combined)
    return (matched / len(query_words)) >= KEYWORD_MATCH_RATIO


def _check_conditions(
    query: str,
    dist: float,
    img_page: int,
    caption: str,
    ocr_text: str,
    text_pages: set,
) -> Tuple[bool, List[str]]:
    """
    Check C1, C2, C3.  ANY 1 passing = image is retrieved.
    Called only AFTER the mandatory gate has already passed.

    C1 — CLIP visual similarity score
    C2 — Page proximity +-PAGE_WINDOW to text pages
    C3 — Caption/OCR keyword match with query (>=25%)
    """
    passed = []

    if _check_c1_clip(dist):
        passed.append("C1:clip_visual")

    if _check_c2_page_proximity(img_page, text_pages):
        passed.append("C2:page_proximity")

    if _check_c3_keyword(query, caption, ocr_text):
        passed.append("C3:keyword_match")

    return len(passed) >= 1, passed


# ════════════════════════════════════════════════════════════════════════════
#  MAIN IMAGE RETRIEVAL
# ════════════════════════════════════════════════════════════════════════════

def retrieve_images(
    query: str,
    text_pages: set,
    text_sources: set,
    top_k: int = TOP_K_IMAGES,
) -> List[Dict]:
    """
    FAISS CLIP search + mandatory gate + 1-of-3 condition filter.
    No LLaVA / Ollama dependency.

    Step 1 — CLIP FAISS search: top N candidates from all images
    Step 2 — MANDATORY gate   : same PDF AND +-PAGE_WINDOW pages
              -> FAIL -> image dropped immediately
    Step 3 — Condition check  : C1 OR C2 OR C3
              -> NONE pass -> image dropped
              -> ANY  pass -> image kept
    Step 4 — Sort by CLIP distance, return top_k

    Final rule:
      (C1 OR C2 OR C3) AND same_pdf AND |img_page - text_page| <= PAGE_WINDOW
    """
    if not Path(FAISS_META_PATH).exists() or not Path(FAISS_INDEX_PATH).exists():
        logger.info("[retriever] No FAISS index — skipping images.")
        return []

    if not text_pages:
        logger.info("[retriever] No text pages found — skipping image retrieval.")
        return []

    try:
        with open(FAISS_META_PATH) as f:
            metadata: list = json.load(f)
        index = faiss.read_index(FAISS_INDEX_PATH)
    except Exception as e:
        logger.error(f"[retriever] FAISS load error: {e}")
        return []

    if not metadata:
        return []

    # CLIP FAISS search
    q_emb      = get_clip_text_embedding(query).astype(np.float32).reshape(1, -1)
    n_cands    = min(top_k * 15, len(metadata))
    distances, indices = index.search(q_emb, n_cands)

    results = []

    for idx, dist in zip(indices[0], distances[0]):
        if idx < 0 or idx >= len(metadata):
            continue

        m          = metadata[idx]
        img_source = m.get("source", "")
        img_page   = m.get("page", 0)
        caption    = m.get("caption", "")
        ocr_text   = m.get("image_text", "")
        img_path   = m.get("image_path", "")
        stored_b64 = m.get("image_base64", "")

        # ── MANDATORY GATE — same PDF + page within +-PAGE_WINDOW ─────────────
        gate_ok, gate_reason = _mandatory_gate(
            img_page, img_source, text_pages, text_sources
        )
        if not gate_ok:
            logger.debug(f"  MANDATORY FAIL p{img_page}: {gate_reason}")
            continue

        # ── CONDITION CHECK — C1 OR C2 OR C3 ─────────────────────────────────
        cond_ok, passed = _check_conditions(
            query, float(dist), img_page, caption, ocr_text, text_pages
        )

        logger.info(
            f"  p{img_page} | dist={dist:.3f} | conditions={passed} "
            f"| src={img_source} "
            f"-> {'KEEP' if cond_ok else 'SKIP'}"
        )

        if not cond_ok:
            continue

        # ── LOAD AND COMPRESS IMAGE ───────────────────────────────────────────
        b64 = _compress_to_b64(img_path=img_path, b64_input=stored_b64)
        if not b64:
            logger.warning(f"  No image data for p{img_page} — skip")
            continue

        results.append({
            "type":         "image",
            "image_path":   img_path,
            "image_base64": b64,
            "page":         img_page,
            "source":       img_source,
            "distance":     float(dist),
            "caption":      caption,
            "ocr_text":     ocr_text,
            "conditions":   passed,
        })

        if len(results) >= top_k:
            break

    # Sort by CLIP distance (lower = more visually similar to query)
    results.sort(key=lambda x: x["distance"])

    logger.info(
        f"[retriever] Images returned: {len(results)} "
        f"(pool={n_cands}, window=+-{PAGE_WINDOW}, "
        f"text_pages={sorted(text_pages)}, text_sources={text_sources})"
    )
    return results


# ════════════════════════════════════════════════════════════════════════════
#  FULL PIPELINE
# ════════════════════════════════════════════════════════════════════════════

def full_retrieve(query: str) -> Tuple[List[Dict], List[Dict]]:
    print(f"\nQuery: {query}")
    print("-" * 70)

    print("Stage 1: ChromaDB text search ...")
    candidates = retrieve_text(query, top_k=TOP_K_RETRIEVE)
    print(f"    -> {len(candidates)} candidates")

    print("Stage 2: CrossEncoder reranking ...")
    top_text = rerank_text(query, candidates, top_k=TOP_K_RERANK)
    print(f"    -> {len(top_text)} kept")

    text_pages   = {c["page"]   for c in top_text if c.get("page")}
    text_sources = {c["source"] for c in top_text if c.get("source")}

    print(f"Stage 3: Image retrieval ...")
    print(f"    MANDATORY : same PDF + page within +-{PAGE_WINDOW} of text pages {sorted(text_pages)}")
    print(f"    CONDITIONS: C1 (CLIP visual) OR C2 (page proximity) OR C3 (keyword match)")
    top_images = retrieve_images(query, text_pages, text_sources)
    print(f"    -> {len(top_images)} images passed all gates")
    print("-" * 70)
    return top_text, top_images
