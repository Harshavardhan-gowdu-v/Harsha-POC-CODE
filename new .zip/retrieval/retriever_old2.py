"""
retrieval/retriever.py — Multimodal Retrieval Pipeline

TEXT/TABLE:
  Stage 1 — ChromaDB cosine search (all-MiniLM-L6-v2, 384-dim)
  Stage 2 — CrossEncoder reranking

IMAGE (FAISS + 1-of-3 condition):
  C1: CLIP distance < threshold      (visual similarity)
  C2: Image page within ±1 of text chunk pages  (proximity)
  C3: Caption/OCR keyword match      (semantic)
  → ANY 1 of 3 conditions = image is shown
"""

import os
import io
import json
import base64
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Any

import numpy as np
from sentence_transformers import CrossEncoder
from PIL import Image

from config import (
    CHROMA_PATH, RERANKER_MODEL, IMAGES_PATH,
    TOP_K_RETRIEVE, TOP_K_RERANK, TOP_K_IMAGES,
    CLIP_DISTANCE_THRESHOLD, IMG_MAX_PX, IMG_QUALITY,
    FAISS_INDEX_PATH, FAISS_META_PATH,
)
from retrieval.embeddings import get_text_embedding, get_clip_text_embedding

try:
    import chromadb
except ImportError:
    raise ImportError("pip install chromadb")

try:
    import faiss
except ImportError:
    raise ImportError("pip install faiss-cpu")

import warnings
warnings.filterwarnings("ignore")

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
logger = logging.getLogger(__name__)

# ── Load reranker once ────────────────────────────────────────────────────────
logger.info(f"[retriever] Loading reranker: {RERANKER_MODEL}")
try:
    _reranker = CrossEncoder(RERANKER_MODEL)
    logger.info("[retriever] ✅ Reranker ready")
except Exception as e:
    logger.error(f"[retriever] Reranker load failed: {e}")
    _reranker = None


# ════════════════════════════════════════════════════════════════════════════
#  CHROMADB — text + table retrieval (from ECS_llava)
# ════════════════════════════════════════════════════════════════════════════

def _get_text_collection():
    os.makedirs(CHROMA_PATH, exist_ok=True)
    client = chromadb.PersistentClient(path=CHROMA_PATH)
    try:
        return client.get_collection("documents")
    except Exception:
        return client.create_collection(
            "documents", metadata={"hnsw:space": "cosine"}
        )


def retrieve_text(query: str, top_k: int = TOP_K_RETRIEVE) -> List[Dict]:
    try:
        col   = _get_text_collection()
        count = col.count()
        if count == 0:
            return []
        q_emb   = get_text_embedding(query)
        results = col.query(
            query_embeddings=[q_emb.tolist()],
            n_results=min(top_k, count),
            include=["documents", "metadatas", "distances"],
        )
        docs = []
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            docs.append({
                "content":  doc,
                "page":     meta.get("page", 0),
                "type":     meta.get("type", "text"),
                "source":   meta.get("source", ""),
                "distance": float(dist),
            })
        return docs
    except Exception as e:
        logger.error(f"[retriever] retrieve_text error: {e}")
        return []


def rerank(query: str, docs: List[Dict], top_k: int = TOP_K_RERANK) -> List[Dict]:
    if not docs:
        return []
    if _reranker is None:
        return sorted(docs, key=lambda d: d["distance"])[:top_k]
    try:
        pairs  = [[query, d["content"]] for d in docs]
        scores = _reranker.predict(pairs)
        ranked = sorted(zip(docs, scores), key=lambda x: x[1], reverse=True)
        return [d for d, _ in ranked[:top_k]]
    except Exception as e:
        logger.error(f"[retriever] rerank error: {e}")
        return docs[:top_k]


# ════════════════════════════════════════════════════════════════════════════
#  IMAGE COMPRESSION
# ════════════════════════════════════════════════════════════════════════════

def _compress_to_b64(img_path: str = "", b64_input: str = "") -> str:
    """
    Load from path (tries first) or stored base64 (fallback).
    Handles stale Windows paths when project is moved.
    """
    try:
        pil = None
        if img_path and os.path.exists(img_path):
            try:
                pil = Image.open(img_path).convert("RGB")
            except Exception as e:
                logger.warning(f"  Cannot open {img_path}: {e}")

        # Fallback: try resolving filename in current IMAGES_PATH
        if pil is None and img_path:
            fname     = Path(img_path.replace("\\", "/")).name
            candidate = os.path.join(IMAGES_PATH, fname)
            if os.path.exists(candidate):
                try:
                    pil = Image.open(candidate).convert("RGB")
                    logger.info(f"  Resolved path → {candidate}")
                except Exception:
                    pass

        # Fallback: stored base64
        if pil is None and b64_input:
            try:
                raw = base64.b64decode(b64_input)
                pil = Image.open(io.BytesIO(raw)).convert("RGB")
            except Exception as e:
                logger.warning(f"  Cannot decode base64: {e}")

        if pil is None:
            return ""

        pil.thumbnail((IMG_MAX_PX, IMG_MAX_PX))
        buf = io.BytesIO()
        pil.save(buf, format="JPEG", quality=IMG_QUALITY, optimize=True)
        b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
        logger.info(f"  Image → {len(b64)*3/4/1024:.1f} KB")
        return b64
    except Exception as e:
        logger.warning(f"  Compress failed: {e}")
        return ""


# ════════════════════════════════════════════════════════════════════════════
#  IMAGE RETRIEVAL — ANY 1 of 3 CONDITIONS (from ECS_TCS, changed to 1-of-3)
# ════════════════════════════════════════════════════════════════════════════

def _check_conditions(
    query: str,
    dist: float,
    img_page: int,
    caption: str,
    ocr_text: str,
    text_pages: set,
) -> Tuple[bool, List[str]]:
    """
    Check 3 conditions. ANY 1 passing = image is retrieved.

    C1 — CLIP visual similarity score
    C2 — Page proximity ±1 to text retrieval pages
    C3 — Caption/OCR keyword match with query
    """
    passed = []

    # C1 — CLIP distance
    if dist <= CLIP_DISTANCE_THRESHOLD:
        passed.append("C1:visual")

    # C2 — Page proximity ±1
    if text_pages:
        nearby = {img_page - 1, img_page, img_page + 1}
        if nearby.intersection(text_pages):
            passed.append("C2:page_proximity")

    # C3 — Keyword match (caption or OCR)
    combined    = f"{caption} {ocr_text}".lower()
    query_words = [w for w in query.lower().split() if len(w) > 3]
    if query_words and combined.strip() and len(combined) > 10:
        matched = sum(1 for w in query_words if w in combined)
        if matched / len(query_words) >= 0.25:
            passed.append("C3:keyword")

    # ANY 1 condition = pass
    return len(passed) >= 1, passed


def retrieve_images(
    query: str,
    text_pages: set,
    text_sources: set,
    top_k: int = TOP_K_IMAGES,
) -> List[Dict]:
    """
    FAISS CLIP search + 1-of-3 condition filter.
    Source-level filter ensures images are from same PDF as text results.
    """
    if not Path(FAISS_META_PATH).exists() or not Path(FAISS_INDEX_PATH).exists():
        logger.info("[retriever] No FAISS index — skipping images.")
        return []

    try:
        with open(FAISS_META_PATH, "r") as f:
            metadata: list = json.load(f)
    except Exception as e:
        logger.error(f"[retriever] Cannot load metadata: {e}")
        return []

    if not metadata:
        return []

    try:
        index = faiss.read_index(FAISS_INDEX_PATH)
    except Exception as e:
        logger.error(f"[retriever] Cannot load FAISS index: {e}")
        return []

    q_emb      = get_clip_text_embedding(query).astype(np.float32).reshape(1, -1)
    n_cands    = min(top_k * 10, len(metadata))
    distances, indices = index.search(q_emb, n_cands)

    results = []
    for idx, dist in zip(indices[0], distances[0]):
        if idx < 0 or idx >= len(metadata):
            continue

        img_data   = metadata[idx]
        img_path   = img_data.get("image_path", "")
        img_source = img_data.get("source", "")
        img_page   = img_data.get("page", 0)
        caption    = img_data.get("caption", "")
        ocr_text   = img_data.get("image_text", "")
        stored_b64 = img_data.get("image_base64", "")

        # Source filter — same PDF only
        if text_sources and img_source not in text_sources:
            logger.debug(f"  Source mismatch: {img_source}")
            continue

        # 1-of-3 condition check
        ok, passed = _check_conditions(
            query, float(dist), img_page, caption, ocr_text, text_pages
        )
        logger.info(
            f"  Image p{img_page} dist={dist:.3f} "
            f"conditions={passed} → {'✅ SHOW' if ok else '❌ SKIP'}"
        )

        if not ok:
            continue

        b64 = _compress_to_b64(img_path=img_path, b64_input=stored_b64)
        if not b64:
            logger.warning(f"  No image data — skip")
            continue

        results.append({
            "type":         "image",
            "image_path":   img_path,
            "image_base64": b64,
            "page":         img_page,
            "source":       img_source,
            "distance":     float(dist),
            "caption":      caption,
            "ocr_text":     ocr_text,
            "conditions":   passed,
        })

        if len(results) >= top_k:
            break

    logger.info(f"[retriever] Images returned: {len(results)}")
    return results


# ════════════════════════════════════════════════════════════════════════════
#  FULL PIPELINE
# ════════════════════════════════════════════════════════════════════════════

def full_retrieve(query: str) -> Tuple[List[Dict], List[Dict]]:
    print(f"\n🔍  Query: {query}")
    print("─" * 70)

    print("📚  Stage 1: ChromaDB text search …")
    candidates = retrieve_text(query, top_k=TOP_K_RETRIEVE)
    print(f"    → {len(candidates)} candidates")

    print("🔄  Stage 2: CrossEncoder reranking …")
    top_text = rerank(query, candidates, top_k=TOP_K_RERANK)
    print(f"    → {len(top_text)} kept")

    text_pages   = {c["page"]   for c in top_text if c.get("page")}
    text_sources = {c["source"] for c in top_text if c.get("source")}

    print(f"🖼️   Stage 3: FAISS image search (pages={sorted(text_pages)}, 1-of-3 filter) …")
    top_images = retrieve_images(query, text_pages, text_sources)
    print(f"    → {len(top_images)} images")
    print("─" * 70)
    return top_text, top_images
