"""
retrieval/retriever.py — Modernized Multimodal Retrieval Pipeline

TEXT/TABLE:
  Stage 1 — ChromaDB cosine search (all-MiniLM-L6-v2, 384-dim)
  Stage 2 — CrossEncoder reranking

IMAGE — 3-Pass system:
  Pass 1 (Recall)    : CLIP visual similarity → top candidates
  Pass 2 (Rerank)    : Weighted RRF score (CLIP + BM25 + Caption vector)
  Pass 3 (Precision) : LLaVA Yes/No gate on top images

CONDITIONS (page ±1 is ALWAYS mandatory):
  MANDATORY : Image page must be within ±1 of text answer pages
              (same PDF, same section — prevents cross-chapter leakage)

  ADDITIONAL (need at least 1 more to pass):
  C1: CLIP distance < threshold      (visual similarity)
  C2: BM25 keyword match on OCR      (lexical match)
  C3: LLaVA-generated caption match  (semantic caption similarity)
  C4: Image category is Informational/Chart (not Decorative/Icon)
"""

import os
import io
import json
import math
import base64
import logging
from pathlib import Path
from typing import List, Dict, Tuple

import numpy as np
from sentence_transformers import CrossEncoder, SentenceTransformer
from PIL import Image

from config import (
    CHROMA_PATH, RERANKER_MODEL, IMAGES_PATH,
    TOP_K_RETRIEVE, TOP_K_RERANK, TOP_K_IMAGES,
    CLIP_DISTANCE_THRESHOLD, IMG_MAX_PX, IMG_QUALITY,
    FAISS_INDEX_PATH, FAISS_META_PATH,
)
from retrieval.embeddings import get_text_embedding, get_clip_text_embedding

try:
    import chromadb
except ImportError:
    raise ImportError("pip install chromadb")

try:
    import faiss
except ImportError:
    raise ImportError("pip install faiss-cpu")

import warnings
warnings.filterwarnings("ignore")

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
logger = logging.getLogger(__name__)


# ════════════════════════════════════════════════════════════════════════════
#  LOAD MODELS ONCE
# ════════════════════════════════════════════════════════════════════════════

logger.info(f"[retriever] Loading reranker: {RERANKER_MODEL}")
try:
    _reranker = CrossEncoder(RERANKER_MODEL)
    logger.info("[retriever] ✅ CrossEncoder ready")
except Exception as e:
    logger.error(f"[retriever] Reranker load failed: {e}")
    _reranker = None

# Caption similarity model (same embedding space as text)
logger.info("[retriever] Loading caption similarity model...")
try:
    _caption_model = SentenceTransformer("all-MiniLM-L6-v2")
    logger.info("[retriever] ✅ Caption model ready")
except Exception as e:
    logger.error(f"[retriever] Caption model failed: {e}")
    _caption_model = None


# ════════════════════════════════════════════════════════════════════════════
#  CHROMADB — TEXT + TABLE RETRIEVAL
# ════════════════════════════════════════════════════════════════════════════

def _get_text_collection():
    os.makedirs(CHROMA_PATH, exist_ok=True)
    client = chromadb.PersistentClient(path=CHROMA_PATH)
    try:
        return client.get_collection("documents")
    except Exception:
        return client.create_collection(
            "documents", metadata={"hnsw:space": "cosine"}
        )


def retrieve_text(query: str, top_k: int = TOP_K_RETRIEVE) -> List[Dict]:
    try:
        col   = _get_text_collection()
        count = col.count()
        if count == 0:
            return []
        q_emb   = get_text_embedding(query)
        results = col.query(
            query_embeddings=[q_emb.tolist()],
            n_results=min(top_k, count),
            include=["documents", "metadatas", "distances"],
        )
        docs = []
        for doc, meta, dist in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ):
            docs.append({
                "content":  doc,
                "page":     meta.get("page", 0),
                "type":     meta.get("type", "text"),
                "source":   meta.get("source", ""),
                "distance": float(dist),
            })
        return docs
    except Exception as e:
        logger.error(f"[retriever] retrieve_text error: {e}")
        return []


def rerank_text(query: str, docs: List[Dict],
                top_k: int = TOP_K_RERANK) -> List[Dict]:
    if not docs:
        return []
    if _reranker is None:
        return sorted(docs, key=lambda d: d["distance"])[:top_k]
    try:
        pairs  = [[query, d["content"]] for d in docs]
        scores = _reranker.predict(pairs)
        ranked = sorted(zip(docs, scores), key=lambda x: x[1], reverse=True)
        return [d for d, _ in ranked[:top_k]]
    except Exception as e:
        logger.error(f"[retriever] rerank error: {e}")
        return docs[:top_k]


# ════════════════════════════════════════════════════════════════════════════
#  IMAGE COMPRESSION
# ════════════════════════════════════════════════════════════════════════════

def _compress_to_b64(img_path: str = "", b64_input: str = "") -> str:
    try:
        pil = None
        if img_path and os.path.exists(img_path):
            try:
                pil = Image.open(img_path).convert("RGB")
            except Exception:
                pass

        if pil is None and img_path:
            fname     = Path(img_path.replace("\\", "/")).name
            candidate = os.path.join(IMAGES_PATH, fname)
            if os.path.exists(candidate):
                try:
                    pil = Image.open(candidate).convert("RGB")
                    logger.info(f"  Resolved → {candidate}")
                except Exception:
                    pass

        if pil is None and b64_input:
            try:
                raw = base64.b64decode(b64_input)
                pil = Image.open(io.BytesIO(raw)).convert("RGB")
            except Exception:
                pass

        if pil is None:
            return ""

        pil.thumbnail((IMG_MAX_PX, IMG_MAX_PX))
        buf = io.BytesIO()
        pil.save(buf, format="JPEG", quality=IMG_QUALITY, optimize=True)
        b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
        logger.info(f"  Image → {len(b64)*3/4/1024:.1f} KB")
        return b64
    except Exception as e:
        logger.warning(f"  Compress failed: {e}")
        return ""


# ════════════════════════════════════════════════════════════════════════════
#  PASS 1 — BM25 SCORE (lexical keyword match on OCR)
# ════════════════════════════════════════════════════════════════════════════

def _bm25_score(query: str, text: str, k1: float = 1.5, b: float = 0.75) -> float:
    """
    Simplified BM25 score between query and OCR/caption text.
    Returns 0.0–1.0 (normalised).
    """
    if not text or not query:
        return 0.0
    query_terms = [w.lower() for w in query.split() if len(w) > 2]
    doc_terms   = text.lower().split()
    doc_len     = len(doc_terms)
    avg_len     = 50.0   # assumed average OCR length

    score = 0.0
    for term in query_terms:
        tf  = doc_terms.count(term)
        idf = math.log(1 + 1 / (0.5 + tf))
        score += idf * (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * doc_len / avg_len))

    # Normalise to 0–1
    max_score = len(query_terms) * math.log(2)
    return min(score / max_score, 1.0) if max_score > 0 else 0.0


# ════════════════════════════════════════════════════════════════════════════
#  PASS 2 — CAPTION VECTOR SIMILARITY
# ════════════════════════════════════════════════════════════════════════════

def _caption_similarity(query: str, caption: str) -> float:
    """
    Cosine similarity between query embedding and LLaVA-generated caption.
    Returns 0.0–1.0.
    """
    if not caption or not _caption_model:
        return 0.0
    try:
        q_emb = _caption_model.encode(query,   normalize_embeddings=True)
        c_emb = _caption_model.encode(caption, normalize_embeddings=True)
        score = float(np.dot(q_emb, c_emb))
        return max(0.0, score)
    except Exception:
        return 0.0


# ════════════════════════════════════════════════════════════════════════════
#  PASS 2 — RECIPROCAL RANK FUSION (RRF) SCORE
# ════════════════════════════════════════════════════════════════════════════

def _rrf_score(clip_dist: float, bm25: float, cap_sim: float,
               k: int = 60) -> float:
    """
    Combine three signals using Reciprocal Rank Fusion concept.
      - CLIP distance   → convert to similarity (lower dist = higher sim)
      - BM25 score      → already 0–1
      - Caption sim     → already 0–1

    Final score is weighted average: CLIP 40%, BM25 30%, Caption 30%.
    """
    clip_sim = max(0.0, 1.0 - clip_dist / 2.0)   # normalise L2 dist 0–2 → sim 0–1
    score    = 0.4 * clip_sim + 0.3 * bm25 + 0.3 * cap_sim
    return score


# ════════════════════════════════════════════════════════════════════════════
#  PASS 3 — LLAVA VISUAL ENTAILMENT GATE
# ════════════════════════════════════════════════════════════════════════════

def _llava_gate(image_b64: str, query: str) -> Tuple[bool, str]:
    """
    Ask LLaVA: 'Does this image visually answer the query? Yes/No'
    Returns (is_relevant: bool, description: str).
    On any failure, defaults to True (keep image — don't drop on error).
    """
    if not image_b64:
        return False, ""
    try:
        import ollama
        from config import VISION_MODEL
        response = ollama.chat(
            model=VISION_MODEL,
            messages=[{
                "role": "user",
                "content": (
                    f"Does this image visually represent or help answer "
                    f"the query: '{query}'?\n\n"
                    f"First describe what you see in 1-2 sentences.\n"
                    f"Then on the LAST LINE write exactly one of:\n"
                    f"ANSWER: yes\n"
                    f"ANSWER: no"
                ),
                "images": [image_b64],
            }],
            options={"num_predict": 150},
            keep_alive=0,
        )
        full  = response["message"]["content"].strip()
        lines = [l.strip() for l in full.splitlines() if l.strip()]
        last  = lines[-1].lower() if lines else ""

        is_relevant = "answer: yes" in last or last.endswith("yes")
        desc = "\n".join(lines[:-1]).strip() if "answer:" in last else full
        logger.info(f"  LLaVA gate → {'YES ✅' if is_relevant else 'NO ❌'}  {desc[:60]}…")
        return is_relevant, desc
    except Exception as e:
        logger.warning(f"  LLaVA gate failed: {e} — keeping image")
        return True, ""


# ════════════════════════════════════════════════════════════════════════════
#  IMAGE CATEGORY CHECK
# ════════════════════════════════════════════════════════════════════════════

def _is_informational(caption: str, ocr_text: str) -> bool:
    """
    Simple heuristic to detect decorative/icon images.
    Returns True if image is likely informational (diagram, chart, figure).
    Returns False if it looks decorative (logo, icon, bullet, small graphic).
    """
    combined = f"{caption} {ocr_text}".lower().strip()

    # Informational signals
    info_signals = [
        "figure", "fig.", "diagram", "chart", "graph", "table",
        "architecture", "flow", "model", "layer", "network",
        "attention", "encoder", "decoder", "matrix", "vector",
    ]
    if any(sig in combined for sig in info_signals):
        return True

    # Decorative signals
    deco_signals = ["logo", "icon", "bullet", "arrow", "©", "trademark"]
    if any(sig in combined for sig in deco_signals):
        return False

    # No strong signal — treat as informational (don't drop unknown)
    return True


# ════════════════════════════════════════════════════════════════════════════
#  MAIN IMAGE RETRIEVAL — 3-PASS SYSTEM
# ════════════════════════════════════════════════════════════════════════════

def retrieve_images(
    query: str,
    text_pages: set,
    text_sources: set,
    top_k: int = TOP_K_IMAGES,
) -> List[Dict]:
    """
    3-Pass image retrieval:

    PASS 1 — Recall (CLIP FAISS search → top candidates)
    PASS 2 — Rerank (RRF: CLIP + BM25 + Caption similarity)
    PASS 3 — Precision (LLaVA Yes/No gate on top images)

    MANDATORY GATE (always applied first):
      ✅ Image page MUST be within ±1 of text answer pages
      ✅ Image source MUST be same PDF as text answer
      → If this fails → image is DROPPED immediately, no further checks.

    ADDITIONAL (need 1+ more after mandatory gate):
      C1: CLIP similarity score (RRF weighted)
      C2: BM25 OCR keyword score (RRF weighted)
      C3: Caption vector similarity (RRF weighted)
      C4: Image is informational (not decorative/icon)
    """
    if not Path(FAISS_META_PATH).exists() or not Path(FAISS_INDEX_PATH).exists():
        logger.info("[retriever] No FAISS index — skipping images.")
        return []

    try:
        with open(FAISS_META_PATH) as f:
            metadata: list = json.load(f)
        index = faiss.read_index(FAISS_INDEX_PATH)
    except Exception as e:
        logger.error(f"[retriever] FAISS load error: {e}")
        return []

    if not metadata:
        return []

    # ── PASS 1: CLIP recall ───────────────────────────────────────────────────
    q_emb      = get_clip_text_embedding(query).astype(np.float32).reshape(1, -1)
    n_cands    = min(top_k * 15, len(metadata))
    distances, indices = index.search(q_emb, n_cands)

    candidates = []
    for idx, dist in zip(indices[0], distances[0]):
        if idx < 0 or idx >= len(metadata):
            continue

        m          = metadata[idx]
        img_source = m.get("source", "")
        img_page   = m.get("page", 0)
        caption    = m.get("caption", "")
        ocr_text   = m.get("image_text", "")
        img_path   = m.get("image_path", "")
        stored_b64 = m.get("image_base64", "")

        # ── MANDATORY GATE 1: Same PDF source ────────────────────────────────
        if text_sources and img_source not in text_sources:
            logger.debug(f"  MANDATORY FAIL: source {img_source}")
            continue

        # ── MANDATORY GATE 2: Page ±1 (ALWAYS enforced) ──────────────────────
        if text_pages:
            nearby = {img_page - 3, img_page - 2, img_page - 1, img_page, img_page + 1, img_page + 2, img_page + 3}
            if not nearby.intersection(text_pages):
                logger.debug(
                    f"  MANDATORY FAIL: page {img_page} not in ±1 of {sorted(text_pages)}"
                )
                continue
        else:
            # No text pages found — skip image retrieval entirely
            logger.info("  No text pages found — skipping image retrieval.")
            return []

        # ── PASS 2: RRF scoring ───────────────────────────────────────────────
        bm25    = _bm25_score(query, f"{caption} {ocr_text}")
        cap_sim = _caption_similarity(query, caption)
        rrf     = _rrf_score(float(dist), bm25, cap_sim)

        # Category filter
        is_info = _is_informational(caption, ocr_text)

        # Need at least 1 additional condition beyond mandatory page gate
        # RRF > 0.15 OR informational category with any CLIP signal
        additional_ok = (
            rrf >= 0.15
            or (is_info and float(dist) <= CLIP_DISTANCE_THRESHOLD)
        )

        logger.info(
            f"  p{img_page} dist={dist:.3f} bm25={bm25:.2f} "
            f"cap={cap_sim:.2f} rrf={rrf:.3f} info={is_info} "
            f"→ {'✅ candidate' if additional_ok else '❌ skip'}"
        )

        if not additional_ok:
            continue

        candidates.append({
            "idx":        idx,
            "rrf_score":  rrf,
            "dist":       float(dist),
            "img_path":   img_path,
            "stored_b64": stored_b64,
            "img_page":   img_page,
            "img_source": img_source,
            "caption":    caption,
            "ocr_text":   ocr_text,
        })

    # Sort by RRF score (best first)
    candidates.sort(key=lambda x: x["rrf_score"], reverse=True)

    # ── PASS 3: LLaVA gate on top candidates ─────────────────────────────────
    results      = []
    llava_budget = min(top_k * 2, len(candidates))   # call llava on up to 2x top_k

    for cand in candidates[:llava_budget]:
        if len(results) >= top_k:
            break

        b64 = _compress_to_b64(
            img_path=cand["img_path"],
            b64_input=cand["stored_b64"],
        )
        if not b64:
            continue

        # LLaVA visual entailment gate
        is_relevant, llava_desc = _llava_gate(b64, query)
        if not is_relevant:
            logger.info(
                f"  LLaVA DROPPED: {cand['img_source']} p{cand['img_page']}"
            )
            continue

        results.append({
            "type":             "image",
            "image_path":       cand["img_path"],
            "image_base64":     b64,
            "page":             cand["img_page"],
            "source":           cand["img_source"],
            "distance":         cand["dist"],
            "rrf_score":        cand["rrf_score"],
            "caption":          cand["caption"],
            "ocr_text":         cand["ocr_text"],
            "llava_description": llava_desc,
        })

    logger.info(f"[retriever] Images returned: {len(results)} "
                f"(from {len(candidates)} candidates, {llava_budget} LLaVA checked)")
    return results


# ════════════════════════════════════════════════════════════════════════════
#  FULL PIPELINE
# ════════════════════════════════════════════════════════════════════════════

def full_retrieve(query: str) -> Tuple[List[Dict], List[Dict]]:
    print(f"\n🔍  Query: {query}")
    print("─" * 70)

    print("📚  Stage 1: ChromaDB text search …")
    candidates = retrieve_text(query, top_k=TOP_K_RETRIEVE)
    print(f"    → {len(candidates)} candidates")

    print("🔄  Stage 2: CrossEncoder reranking …")
    top_text = rerank_text(query, candidates, top_k=TOP_K_RERANK)
    print(f"    → {len(top_text)} kept")

    text_pages   = {c["page"]   for c in top_text if c.get("page")}
    text_sources = {c["source"] for c in top_text if c.get("source")}

    print(f"🖼️   Stage 3: Image retrieval (pages={sorted(text_pages)}) …")
    print(f"    MANDATORY: page ±1 | ADDITIONAL: CLIP+BM25+Caption RRF | LLaVA gate")
    top_images = retrieve_images(query, text_pages, text_sources)
    print(f"    → {len(top_images)} images passed all gates")
    print("─" * 70)
    return top_text, top_images