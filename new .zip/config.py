"""
config.py — All settings in one place.
"""
import os
import socket

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ── Paths ─────────────────────────────────────────────────────────────────
DOCS_PATH        = os.path.join(BASE_DIR, "data", "input_pdfs")
CHROMA_PATH      = os.path.join(BASE_DIR, "data", "chroma_db")
IMAGES_PATH      = os.path.join(BASE_DIR, "data", "images")
FAISS_INDEX_PATH = os.path.join(BASE_DIR, "data", "faiss_image_index.bin")
FAISS_META_PATH  = os.path.join(BASE_DIR, "data", "faiss_image_meta.json")

# ── Models ────────────────────────────────────────────────────────────────
TEXT_EMBED_MODEL = "all-MiniLM-L6-v2"
CLIP_MODEL       = "clip-ViT-B-32"
ANSWER_MODEL     = "llama3.2"
RERANKER_MODEL   = "cross-encoder/ms-marco-MiniLM-L-6-v2"
# VISION_MODEL   = "llava"   # removed — LLaVA no longer used anywhere

# ── Chunking ──────────────────────────────────────────────────────────────
CHUNK_SIZE    = 300
CHUNK_OVERLAP = 50

# ── Retrieval ─────────────────────────────────────────────────────────────
TOP_K_RETRIEVE = 10
TOP_K_RERANK   = 5
TOP_K_IMAGES   = 3

# ── Image retrieval — page proximity window ───────────────────────────────
# Images must be within PAGE_WINDOW pages of the text answer page.
# This is the MANDATORY gate applied to ALL images before C1/C2/C3 checks.
# C2 condition also uses this same window.
# Default: 3  (i.e. image page must be within ±3 of text answer pages)
PAGE_WINDOW = 3

# ── Image retrieval — CLIP threshold ─────────────────────────────────────
# CLIP L2 distance: 0 = identical, 2 = completely different.
# C1 passes when dist < CLIP_DISTANCE_THRESHOLD.
# Lower = stricter visual match required.
# Default: 1.2
CLIP_DISTANCE_THRESHOLD = 1.2

# ── Image retrieval — keyword match ratio ────────────────────────────────
# C3 passes when at least this fraction of query words appear in
# caption + OCR text. Range 0.0–1.0. Default: 0.25 (25%).
KEYWORD_MATCH_RATIO = 0.25

# ── Image display ─────────────────────────────────────────────────────────
IMG_MAX_PX  = 400
IMG_QUALITY = 45

# ── Server ────────────────────────────────────────────────────────────────
API_HOST = "0.0.0.0"
API_PORT = 8100

def _get_lan_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "localhost"

IMAGE_HOST = _get_lan_ip()

# ── Auto-create folders ───────────────────────────────────────────────────
for _p in [DOCS_PATH, CHROMA_PATH, IMAGES_PATH]:
    os.makedirs(_p, exist_ok=True)
