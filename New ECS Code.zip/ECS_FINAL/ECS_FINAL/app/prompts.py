"""
app/prompts.py — RAG prompt builder (from ECS_llava, extended for llava descriptions)
"""


def build_rag_prompt(query: str, text_chunks: list, image_chunks: list = None) -> str:
    image_chunks = image_chunks or []

    # ── Text / table context ──────────────────────────────────────────────────
    context_parts = []
    for c in text_chunks:
        tag = f"[{c['type'].upper()} | {c['source']} | Page {c['page']}]"
        context_parts.append(f"{tag}\n{c['content']}")
    context = "\n\n---\n\n".join(context_parts)[:5000]

    # ── Image context (llava description > OCR > caption) ────────────────────
    image_section = ""
    if image_chunks:
        parts = []
        for i, img in enumerate(image_chunks, 1):
            lines = [f"Image {i}: {img['source']}, Page {img['page']}"]
            if img.get("caption"):
                lines.append(f"  Caption: {img['caption']}")
            # Prefer llava description if available
            if img.get("llava_description"):
                lines.append(f"  Visual description: {img['llava_description'][:300]}")
            elif img.get("ocr_text"):
                lines.append(f"  Description: {img['ocr_text'][:200]}")
            parts.append("\n".join(lines))

        image_section = (
            "\n\n=== RELEVANT FIGURES ===\n"
            + "\n\n".join(parts)
            + "\n\nWhen answering, reference figures by number, e.g. 'See Image 1 below'."
        )

    # ── Final prompt ──────────────────────────────────────────────────────────
    prompt = f"""You are a precise document assistant. Answer ONLY using the context below.

ANSWER FORMAT (use plain text paragraphs, NO markdown tables, NO code blocks):
1. **Definition** — 1-2 sentence definition
2. **Explanation** — Detail from the document with page citations like (Page N)
3. **Sub-topics** — Related sub-concepts from the document
4. **Figures** — If figures were found, say "See Image 1 below" (do NOT describe the image in detail)
5. **Summary** — One-sentence takeaway
6. **Source** — Filename and page range

STRICT RULES:
- Use ONLY the provided context. No outside knowledge.
- Do NOT generate markdown tables or code blocks.
- Do NOT embed or describe image URLs. Just reference figures by number.
- If the answer is not in the context, reply: "Not found in documents."

=== CONTEXT ===
{context}{image_section}
=== END CONTEXT ===

Question: {query}

Answer:"""

    return prompt
