"""
app/llm.py — Dual-model RAG:
  llava     → describes each retrieved image (vision LLM)
  llama3.2  → generates answer using text chunks + image descriptions

Images are inline base64 in response for OpenWebUI rendering.
"""
import time
import logging
import ollama

from config import ANSWER_MODEL, VISION_MODEL
from app.prompts import build_rag_prompt
from retrieval.retriever import full_retrieve

logger = logging.getLogger(__name__)


# ── llava: describe image in context of query ─────────────────────────────────

def _describe_with_llava(img: dict, query: str) -> str:
    b64 = img.get("image_base64", "")
    if not b64:
        return ""
    try:
        response = ollama.chat(
            model=VISION_MODEL,
            messages=[{
                "role": "user",
                "content": (
                    f"This image is from a technical document. "
                    f"The user's question is: '{query}'\n\n"
                    f"Describe this image in detail: what it shows, "
                    f"all visible labels and text, the structure or flow, "
                    f"and how it relates to the question."
                ),
                "images": [b64],
            }],
            options={"num_predict": 250},
            keep_alive=0,
        )
        desc = response["message"]["content"].strip()
        logger.info(f"  llava: {desc[:80]}…")
        return desc
    except Exception as e:
        logger.warning(f"  llava failed: {e}")
        return ""


# ── Markdown image block (inline base64) ─────────────────────────────────────

def _img_to_markdown(img: dict, number: int, description: str = "") -> str:
    b64     = img.get("image_base64", "")
    page    = img.get("page", "?")
    source  = img.get("source", "")
    caption = img.get("caption", "")

    if not b64:
        return f"\n\n*[Image {number}: not available]*\n"

    label      = caption if caption else f"Figure from {source}, Page {page}"
    desc_block = f"\n> 📝 *{description[:250]}*\n" if description else ""

    return (
        f"\n\n**Image {number}** — *{source}, Page {page}*"
        + (f"\n*{caption[:100]}*" if caption else "")
        + f"\n\n![{label}](data:image/jpeg;base64,{b64})\n"
        + desc_block
    )


def _build_image_section(image_chunks: list, descriptions: list) -> str:
    if not image_chunks:
        return ""
    parts = ["\n\n---\n### 🖼️ Relevant Figures\n"]
    for i, img in enumerate(image_chunks, 1):
        desc = descriptions[i - 1] if i <= len(descriptions) else ""
        parts.append(_img_to_markdown(img, i, desc))
    return "".join(parts)


# ── Non-streaming ──────────────────────────────────────────────────────────────

def generate_answer(query: str) -> str:
    t0 = time.time()
    text_chunks, image_chunks = full_retrieve(query)
    t_ret = time.time() - t0

    if not text_chunks and not image_chunks:
        return "No relevant data found in the ingested documents."

    descriptions = [_describe_with_llava(img, query) for img in image_chunks]

    enriched = []
    for img, desc in zip(image_chunks, descriptions):
        e = dict(img)
        if desc:
            e["llava_description"] = desc
        enriched.append(e)

    prompt = build_rag_prompt(query, text_chunks, enriched)

    t_llm = time.time()
    try:
        response = ollama.chat(
            model=ANSWER_MODEL,
            messages=[{"role": "user", "content": prompt}],
            options={"num_ctx": 4096, "num_predict": 1024},
            keep_alive=0,
        )
        answer = response["message"]["content"]
    except Exception as e:
        return f"LLM error: {e}\n\nMake sure Ollama is running: `ollama serve`"
    t_llm_done = time.time() - t_llm

    answer += _build_image_section(image_chunks, descriptions)

    total = time.time() - t0
    answer += (
        f"\n\n---\n*Retrieval: {t_ret:.1f}s · LLM: {t_llm_done:.1f}s · "
        f"Total: {total:.1f}s · Text: {ANSWER_MODEL} · Vision: {VISION_MODEL}*"
    )
    return answer


# ── Streaming ──────────────────────────────────────────────────────────────────

def generate_answer_stream(query: str):
    t0 = time.time()
    text_chunks, image_chunks = full_retrieve(query)
    t_ret = time.time() - t0

    if not text_chunks and not image_chunks:
        yield "No relevant data found in the ingested documents."
        return

    # Describe images with llava before streaming
    descriptions = []
    if image_chunks:
        yield f"*🔍 Analyzing {len(image_chunks)} figure(s) with {VISION_MODEL}…*\n\n"
        for i, img in enumerate(image_chunks, 1):
            yield f"*Describing Image {i}…*\n\n"
            desc = _describe_with_llava(img, query)
            descriptions.append(desc)

    enriched = []
    for img, desc in zip(image_chunks, descriptions):
        e = dict(img)
        if desc:
            e["llava_description"] = desc
        enriched.append(e)

    prompt = build_rag_prompt(query, text_chunks, enriched)

    t_llm = time.time()
    try:
        for chunk in ollama.chat(
            model=ANSWER_MODEL,
            messages=[{"role": "user", "content": prompt}],
            stream=True,
            options={"num_ctx": 4096, "num_predict": 1024},
            keep_alive=0,
        ):
            token = chunk["message"]["content"]
            if token:
                yield token
    except Exception as e:
        yield f"\n\n[LLM Error: {e}]"
        return
    t_llm_done = time.time() - t_llm

    # Yield entire image section as ONE token (keeps base64 URI intact for OpenWebUI)
    img_section = _build_image_section(image_chunks, descriptions)
    if img_section:
        yield img_section

    total = time.time() - t0
    yield (
        f"\n\n---\n*Retrieval: {t_ret:.1f}s · LLM: {t_llm_done:.1f}s · "
        f"Total: {total:.1f}s · Text: {ANSWER_MODEL} · Vision: {VISION_MODEL}*"
    )
