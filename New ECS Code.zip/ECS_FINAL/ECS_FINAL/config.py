"""
config.py — All settings in one place.
"""
import os
import socket

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ── Paths ─────────────────────────────────────────────────────────────────
DOCS_PATH        = os.path.join(BASE_DIR, "data", "input_pdfs")
CHROMA_PATH      = os.path.join(BASE_DIR, "data", "chroma_db")
IMAGES_PATH      = os.path.join(BASE_DIR, "data", "images")
FAISS_INDEX_PATH = os.path.join(BASE_DIR, "data", "faiss_image_index.bin")
FAISS_META_PATH  = os.path.join(BASE_DIR, "data", "faiss_image_meta.json")

# ── Models ────────────────────────────────────────────────────────────────
TEXT_EMBED_MODEL = "all-MiniLM-L6-v2"
CLIP_MODEL       = "clip-ViT-B-32"
ANSWER_MODEL     = "llama3.2"
VISION_MODEL     = "llava"
RERANKER_MODEL   = "cross-encoder/ms-marco-MiniLM-L-6-v2"

# ── Chunking ──────────────────────────────────────────────────────────────
CHUNK_SIZE    = 300
CHUNK_OVERLAP = 50

# ── Retrieval ─────────────────────────────────────────────────────────────
TOP_K_RETRIEVE = 10
TOP_K_RERANK   = 5
TOP_K_IMAGES   = 3

# ── Image retrieval threshold ─────────────────────────────────────────────
# CLIP L2 distance: 0=identical, 2=completely different
# Any ONE of the 3 conditions below must pass for image to be shown:
#   C1: CLIP distance < CLIP_DISTANCE_THRESHOLD
#   C2: Image page within ±1 of text answer pages
#   C3: Caption/OCR contains query keywords (>=25% match)
CLIP_DISTANCE_THRESHOLD = 1.2

# ── Image display ─────────────────────────────────────────────────────────
IMG_MAX_PX  = 400
IMG_QUALITY = 45

# ── Server ────────────────────────────────────────────────────────────────
API_HOST = "0.0.0.0"
API_PORT = 8100

def _get_lan_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "localhost"

IMAGE_HOST = _get_lan_ip()

# ── Auto-create folders ───────────────────────────────────────────────────
for _p in [DOCS_PATH, CHROMA_PATH, IMAGES_PATH]:
    os.makedirs(_p, exist_ok=True)
