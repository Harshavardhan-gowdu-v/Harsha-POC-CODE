@echo off
title ECS FINAL RAG - Stopping All Services
color 0C

echo ========================================
echo   Stopping ECS FINAL RAG System
echo ========================================
echo.

echo [1/3] Stopping Open WebUI...
taskkill /F /FI "WINDOWTITLE eq Open WebUI*" >nul 2>&1
taskkill /F /IM open-webui.exe >nul 2>&1
echo       Done

echo [2/3] Stopping RAG Server...
taskkill /F /FI "WINDOWTITLE eq RAG Server*" >nul 2>&1
for /f "tokens=2" %%a in ('tasklist /FI "IMAGENAME eq python.exe" /FO CSV /NH 2^>nul') do (
    taskkill /F /PID %%a >nul 2>&1
)
echo       Done

echo [3/3] Stopping Ollama...
taskkill /F /FI "WINDOWTITLE eq Ollama*" >nul 2>&1
taskkill /F /IM ollama.exe >nul 2>&1
echo       Done

echo.
echo ========================================
echo   All Services Stopped
echo ========================================
echo.
timeout /t 3 /nobreak >nul
exit
