@echo off
title ECS FINAL RAG - Add New Files and Start
color 0B

echo ========================================
echo   Add New PDFs and Start ECS FINAL RAG
echo ========================================
echo.

:: ── Step 1: Start Ollama ────────────────────────────
echo [1/5] Checking Ollama...
tasklist /FI "IMAGENAME eq ollama.exe" 2>NUL | find /I "ollama.exe" >NUL
if %ERRORLEVEL% == 0 (
    echo       Ollama already running
) else (
    echo       Starting Ollama...
    start "Ollama" cmd /k "ollama serve"
    timeout /t 15 /nobreak >nul
)
echo       Done
echo.

:: ── Step 2: Ingest text + tables ────────────────────
echo [2/5] Ingesting PDFs (text + tables)...
cd /d C:\Users\LENOVO\Desktop\ECS_FINAL
C:\Users\LENOVO\Desktop\ECS_FINAL\venv\Scripts\python.exe ingest.py
echo       Done
echo.

:: ── Step 3: Ingest images ───────────────────────────
echo [3/5] Ingesting images...
C:\Users\LENOVO\Desktop\ECS_FINAL\venv\Scripts\python.exe ingest_images.py
echo       Done
echo.

:: ── Step 4: Start RAG Server ────────────────────────
echo [4/5] Starting RAG Server...
start "RAG Server" cmd /k "cd /d C:\Users\LENOVO\Desktop\ECS_FINAL && C:\Users\LENOVO\Desktop\ECS_FINAL\venv\Scripts\python.exe run.py"
echo       Waiting 60 seconds for models to load...
timeout /t 60 /nobreak >nul
echo       Done
echo.

:: ── Step 5: Start Open WebUI ────────────────────────
echo [5/5] Starting Open WebUI...
start "Open WebUI" cmd /k "C:\Users\LENOVO\AppData\Local\Programs\Python\Python311\Scripts\open-webui.exe serve"
echo       Waiting 45 seconds...
timeout /t 45 /nobreak >nul
start http://localhost:8080
echo       Done
echo.

echo ========================================
echo   All Services Started!
echo ========================================
echo   Open WebUI : http://localhost:8080
echo   RAG API    : http://localhost:8100
echo ========================================
echo.
pause
exit
