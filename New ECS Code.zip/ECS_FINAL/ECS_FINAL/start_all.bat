@echo off
title ECS FINAL RAG - Starting All Services
color 0A

echo ========================================
echo   Starting ECS FINAL RAG System
echo ========================================
echo.

:: ── Step 1: Start Ollama ────────────────────────────
echo [1/4] Checking Ollama...
tasklist /FI "IMAGENAME eq ollama.exe" 2>NUL | find /I "ollama.exe" >NUL
if %ERRORLEVEL% == 0 (
    echo       Ollama already running
) else (
    echo       Starting Ollama...
    start "Ollama" cmd /k "ollama serve"
    echo       Waiting 15 seconds for Ollama...
    timeout /t 15 /nobreak >nul
)
echo       Done
echo.

:: ── Step 2: Start RAG Server (uses venv) ────────────
echo [2/4] Starting RAG Server...
start "RAG Server" cmd /k "cd /d C:\Users\LENOVO\Desktop\ECS_FINAL && C:\Users\LENOVO\Desktop\ECS_FINAL\venv\Scripts\python.exe run.py"
echo       Waiting 60 seconds for models to load...
timeout /t 60 /nobreak >nul
echo       Done
echo.

:: ── Step 3: Start Open WebUI (uses system Python) ───
echo [3/4] Starting Open WebUI...
start "Open WebUI" cmd /k "C:\Users\LENOVO\AppData\Local\Programs\Python\Python311\Scripts\open-webui.exe serve"
echo       Waiting 45 seconds for Open WebUI...
timeout /t 45 /nobreak >nul
echo       Done
echo.

:: ── Step 4: Open Browser ────────────────────────────
echo [4/4] Opening browser...
start http://localhost:8080
echo       Done
echo.

echo ========================================
echo   All Services Started!
echo ========================================
echo   Open WebUI : http://localhost:8080
echo   RAG API    : http://localhost:8100
echo   Health     : http://localhost:8100/health
echo ========================================
echo.
echo   Keep all terminal windows OPEN
echo   To stop: run stop_all.bat
echo.
pause
exit
