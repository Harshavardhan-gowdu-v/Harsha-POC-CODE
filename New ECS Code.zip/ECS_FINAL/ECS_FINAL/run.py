"""
run.py — Start the RAG server
    python run.py
"""
import uvicorn
from config import API_HOST, API_PORT, IMAGE_HOST

if __name__ == "__main__":
    print(f"""
╔══════════════════════════════════════════════════════════════╗
║           🚀  MULTIMODAL RAG SERVER  v3.0                    ║
╠══════════════════════════════════════════════════════════════╣
║  Local URL   : http://localhost:{API_PORT}                       ║
║  Network URL : http://{IMAGE_HOST}:{API_PORT}               ║
║  OpenWebUI   : http://{IMAGE_HOST}:{API_PORT}/v1            ║
║  Health      : http://localhost:{API_PORT}/health                ║
║  Model name  : rag-model                                     ║
╠══════════════════════════════════════════════════════════════╣
║  📱 Phone/Tablet: use Network URL above in OpenWebUI         ║
╚══════════════════════════════════════════════════════════════╝
""")
    uvicorn.run(
        "app.main:app",
        host=API_HOST,
        port=API_PORT,
        reload=False,
        log_level="warning",
    )
