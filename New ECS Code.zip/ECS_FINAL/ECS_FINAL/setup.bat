@echo off
title ECS FINAL - Virtual Environment Setup
color 0A

echo ========================================
echo   ECS FINAL - First Time Setup
echo ========================================
echo.

cd /d C:\Users\LENOVO\Desktop\ECS_FINAL

echo [1/4] Creating virtual environment...
C:\Users\LENOVO\AppData\Local\Programs\Python\Python311\python.exe -m venv venv
if errorlevel 1 (
    echo ERROR: Failed to create venv!
    pause
    exit /b 1
)
echo       Done
echo.

echo [2/4] Activating virtual environment...
call venv\Scripts\activate.bat
echo       Done
echo.

echo [3/4] Upgrading pip...
venv\Scripts\python.exe -m pip install --upgrade pip
echo       Done
echo.

echo [4/4] Installing packages (takes 5-10 mins)...
venv\Scripts\pip.exe install -r requirements.txt
echo       Done
echo.

echo ========================================
echo   Setup Complete!
echo   Now double-click start_all.bat
echo ========================================
pause
