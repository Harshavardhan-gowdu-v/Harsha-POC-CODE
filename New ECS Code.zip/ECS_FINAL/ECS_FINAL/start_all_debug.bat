@echo off
title ECS FINAL RAG - DEBUG MODE
color 0E

echo ========================================
echo   DEBUG MODE - All windows stay open
echo ========================================
echo.

:: ── Step 1: Start Ollama ────────────────────────────
echo [1/3] Starting Ollama...
start "Ollama Debug" cmd /k "echo === OLLAMA === && ollama serve"
echo       Waiting 10 seconds...
timeout /t 10 /nobreak >nul

curl -s http://localhost:11434/api/tags >nul 2>&1
if %ERRORLEVEL% == 0 (
    echo       Ollama OK
) else (
    echo       Ollama NOT responding!
)
echo.

:: ── Step 2: Start RAG Server ────────────────────────
echo [2/3] Starting RAG Server...
start "RAG Debug" cmd /k "echo === RAG SERVER === && cd /d C:\Users\LENOVO\Desktop\ECS_FINAL && C:\Users\LENOVO\Desktop\ECS_FINAL\venv\Scripts\python.exe run.py"
echo       Waiting 30 seconds...
timeout /t 30 /nobreak >nul

curl -s http://localhost:8100/health >nul 2>&1
if %ERRORLEVEL% == 0 (
    echo       RAG Server OK
) else (
    echo       RAG Server NOT responding - check RAG Debug window!
)
echo.

:: ── Step 3: Start Open WebUI ────────────────────────
echo [3/3] Starting Open WebUI...
start "WebUI Debug" cmd /k "echo === OPEN WEBUI === && C:\Users\LENOVO\AppData\Local\Programs\Python\Python311\Scripts\open-webui.exe serve"
echo       Waiting 30 seconds...
timeout /t 30 /nobreak >nul

curl -s http://localhost:8080 >nul 2>&1
if %ERRORLEVEL% == 0 (
    echo       Open WebUI OK
) else (
    echo       Open WebUI NOT responding - check WebUI Debug window!
)
echo.

echo ========================================
echo   Check all 3 debug windows for errors
echo ========================================
echo   Ollama Debug : Listening on 127.0.0.1:11434
echo   RAG Debug    : Uvicorn running on port 8100
echo   WebUI Debug  : Uvicorn running on port 8080
echo.
echo   If all OK: http://localhost:8080
echo.
pause
