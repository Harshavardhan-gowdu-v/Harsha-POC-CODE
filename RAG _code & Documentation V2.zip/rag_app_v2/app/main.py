"""
app/main.py — FastAPI entrypoint.

Exposes an OpenAI-compatible API so Open WebUI can connect to it.
Open WebUI thinks it's talking to OpenAI, but it's actually talking
to your local RAG pipeline.

Endpoints:
  GET  /v1/models              → list available models
  POST /v1/chat/completions    → handle chat messages (stream + non-stream)
  GET  /health                 → system status
"""
import json
import time
import uuid

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Optional

from app.llm import generate_answer, generate_answer_stream
from retrieval.vectorstore import get_stats

# ═══════════════════════════════════════════════════════════════
#  FASTAPI APP
# ═══════════════════════════════════════════════════════════════

app = FastAPI(
    title="Multimodal RAG API",
    description="OpenAI-compatible RAG server for Open WebUI",
    version="1.0.0",
)


# ═══════════════════════════════════════════════════════════════
#  REQUEST/RESPONSE MODELS
# ═══════════════════════════════════════════════════════════════

class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    model: str
    messages: List[Message]
    stream: Optional[bool] = False
    temperature: Optional[float] = 0.1


# ═══════════════════════════════════════════════════════════════
#  ENDPOINTS
# ═══════════════════════════════════════════════════════════════

@app.get("/v1/models")
def list_models():
    """
    Open WebUI calls this to discover available models.
    We advertise one model: rag-model
    """
    return {
        "object": "list",
        "data": [
            {
                "id": "rag-model",
                "object": "model",
                "owned_by": "local-rag",
                "created": 1700000000,
            }
        ],
    }


@app.post("/v1/chat/completions")
async def chat_completions(req: ChatRequest):
    try:
        user_msgs = [m for m in req.messages if m.role == "user"]
        if not user_msgs:
            raise HTTPException(status_code=400, detail="No user message found")

        question = user_msgs[-1].content
        req_id = f"chatcmpl-{uuid.uuid4().hex[:8]}"
        created = int(time.time())

        if req.stream:
            def streamer():
                try:
                    for token in generate_answer_stream(question):
                        data = {
                            "id": req_id,
                            "object": "chat.completion.chunk",
                            "created": created,
                            "model": "rag-model",
                            "choices": [{
                                "index": 0,
                                "delta": {"content": token},
                                "finish_reason": None,
                            }],
                        }
                        yield f"data: {json.dumps(data)}\n\n"
                except Exception as e:
                    error_data = {
                        "id": req_id,
                        "object": "chat.completion.chunk",
                        "created": created,
                        "model": "rag-model",
                        "choices": [{
                            "index": 0,
                            "delta": {"content": f"\n\n[Error: {str(e)}]"},
                            "finish_reason": None,
                        }],
                    }
                    yield f"data: {json.dumps(error_data)}\n\n"

                final = {"choices": [{"finish_reason": "stop"}]}
                yield f"data: {json.dumps(final)}\n\n"
                yield "data: [DONE]\n\n"

            return StreamingResponse(streamer(), media_type="text/event-stream")

        # Non-streaming
        answer = generate_answer(question)
        return {
            "id": req_id,
            "object": "chat.completion",
            "created": created,
            "model": "rag-model",
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": answer},
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        }

    except HTTPException:
        raise
    except Exception as e:
        print(f"[main.py] ERROR: {e}")
        return {
            "id": "error",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": "rag-model",
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": f"Server error: {str(e)}. Please try again."},
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        }
    """
    Main chat endpoint — handles every message from Open WebUI.

    Flow:
      1. Extract the latest user message
      2. Run the full RAG pipeline (retrieve → rerank → LLM)
      3. Return the answer in OpenAI's format

    Supports both streaming (stream=True) and non-streaming.
    """
    # Find the latest user message
    user_msgs = [m for m in req.messages if m.role == "user"]
    if not user_msgs:
        raise HTTPException(status_code=400, detail="No user message found")

    question = user_msgs[-1].content
    req_id = f"chatcmpl-{uuid.uuid4().hex[:8]}"
    created = int(time.time())

    # ── STREAMING MODE ────────────────────────────────────────
    if req.stream:
        def streamer():
            for token in generate_answer_stream(question):
                data = {
                    "id": req_id,
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": "rag-model",
                    "choices": [{
                        "index": 0,
                        "delta": {"content": token},
                        "finish_reason": None,
                    }],
                }
                yield f"data: {json.dumps(data)}\n\n"

            # Send the [DONE] signal
            final = {"choices": [{"finish_reason": "stop"}]}
            yield f"data: {json.dumps(final)}\n\n"
            yield "data: [DONE]\n\n"

        return StreamingResponse(streamer(), media_type="text/event-stream")

    # ── NON-STREAMING MODE ────────────────────────────────────
    answer = generate_answer(question)

    return {
        "id": req_id,
        "object": "chat.completion",
        "created": created,
        "model": "rag-model",
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": answer},
            "finish_reason": "stop",
        }],
        "usage": {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0,
        },
    }


@app.get("/v1/health")
def v1_health():
    return {"status": "ok"}


@app.get("/health")
def health():
    """Health check — shows ChromaDB chunk counts."""
    stats = get_stats()
    return {
        "status": "ok",
        "text_chunks": stats["text_chunks"],
        "image_chunks": stats["image_chunks"],
    }


@app.get("/")
def root():
    """Root endpoint — confirms server is running."""
    return {
        "status": "running",
        "message": "RAG API is live. Connect Open WebUI to http://127.0.0.1:8100/v1",
    }
