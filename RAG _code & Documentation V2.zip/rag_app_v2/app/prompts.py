"""
app/prompts.py — RAG prompt templates (with image support).
"""


def build_rag_prompt(query: str, text_chunks: list, image_chunks: list = None) -> str:
    context_parts = []
    for c in text_chunks:
        label = f"[{c['type'].upper()}]"
        context_parts.append(f"{label}\n{c['content']}")

    context = "\n\n---\n\n".join(context_parts)[:5000]

    prompt = f"""You are a document expert. Answer ONLY from the context below.

ANSWER FORMAT (follow this strictly):
1. **Definition** — Define the concept clearly
2. **Explanation** — Explain in detail from the document (around 1000 characters if content is available)
3. **Sub-topics** — If any related sub-topics are mentioned, explain them briefly
4. **Conclusion** — Summarize the key takeaway
5. **References** — Mention the document name as reference

RULES:
- Only answer from the provided context, nothing else
- If tables exist in context, include the most relevant one as a markdown table
- Keep answer around 1000 characters if enough content is available
- If not found, say "Not found in documents."

Context:
{context}

Question: {query}

Answer:"""

    return prompt
    
    """
    Build a grounded RAG prompt from retrieved text + image chunks.

    The prompt includes:
      - Text/table context with source citations
      - Image references (file path, source, page) if found
      - Strict instruction to answer only from context
    """
    # ── Text context ──────────────────────────────────────────
    context_parts = []
    for c in text_chunks:
        label = "[{} | {} | Page {}]".format(
            c["type"].upper(),
            c["source"],
            c["page"],
        )
        context_parts.append(f"{label}\n{c['content']}")

    context = "\n\n---\n\n".join(context_parts)[:4000]

    # ── Image references ──────────────────────────────────────
    image_section = ""
    if image_chunks:
        img_refs = []
        for img in image_chunks:
            img_refs.append(
                f"  - Image found in: {img['source']}, Page {img['page']}"
                f"\n    File: {img.get('image_path', 'N/A')}"
                f"\n    Description: {img.get('content', '')}"
            )
        image_section = "\n\nRELEVANT IMAGES FOUND IN DOCUMENTS:\n" + "\n".join(img_refs)
        image_section += "\n\nIMPORTANT: Always mention these images in your answer. Tell the user which page and source file contains the relevant image."

    # ── Final prompt ──────────────────────────────────────────
    prompt = f"""Answer ONLY from the context below. Cite page numbers.
If not found, say "Not found in documents."
If images are mentioned, reference them in your answer.

=== CONTEXT ===
{context}{image_section}
=== END CONTEXT ===

Question: {query}

Answer:"""

    return prompt
