"""
app/llm.py — Ollama LLM generation (with image support + timing).
"""
import time
import base64
import os
import ollama
from config import ANSWER_MODEL
from app.prompts import build_rag_prompt
from retrieval.retriever import full_retrieve


def _image_to_markdown(image_path: str) -> str:
    """Convert a local image to small base64 for Open WebUI."""
    if not os.path.exists(image_path):
        return f"\n\n*[Image not found]*\n"
    try:
        from PIL import Image
        import io
        img = Image.open(image_path).convert("RGB")
        img.thumbnail((400, 400))
        buffer = io.BytesIO()
        img.save(buffer, format="JPEG", quality=50)
        b64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
        return f"\n\n![image](data:image/jpeg;base64,{b64})\n"
    except Exception:
        return f"\n\n*[Could not load image]*\n"


def generate_answer(query: str) -> str:
    start = time.time()

    text_chunks, image_chunks = full_retrieve(query)
    retrieval_time = time.time() - start

    if not text_chunks and not image_chunks:
        return "No relevant data found in documents."

    prompt = build_rag_prompt(query, text_chunks, image_chunks)

    llm_start = time.time()
    response = ollama.chat(
        model=ANSWER_MODEL,
        messages=[{"role": "user", "content": prompt}],
        options={"num_ctx": 2048, "num_predict": 512},
        keep_alive=0,
    )
    llm_time = time.time() - llm_start
    total_time = time.time() - start

    answer = response["message"]["content"]

    # Append images as base64 inline
    if image_chunks:
        for img in image_chunks:
            img_path = img.get("image_path", "")
            answer += _image_to_markdown(img_path)

    # Append timing info
    answer += f"\n\n---\n*Retrieval: {retrieval_time:.1f}s | LLM: {llm_time:.1f}s | Total: {total_time:.1f}s*"

    return answer


def generate_answer_stream(query: str):
    start = time.time()

    text_chunks, image_chunks = full_retrieve(query)
    retrieval_time = time.time() - start

    if not text_chunks and not image_chunks:
        yield "No relevant data found in documents."
        return

    prompt = build_rag_prompt(query, text_chunks, image_chunks)

    llm_start = time.time()
    for chunk in ollama.chat(
        model=ANSWER_MODEL,
        messages=[{"role": "user", "content": prompt}],
        stream=True,
        options={"num_ctx": 2048, "num_predict": 512},
        keep_alive=0,
    ):
        yield chunk["message"]["content"]

    llm_time = time.time() - llm_start
    total_time = time.time() - start

    # After streaming text, append images
    if image_chunks:
        for img in image_chunks:
            img_path = img.get("image_path", "")
            yield _image_to_markdown(img_path)

    yield f"\n\n---\n*Retrieval: {retrieval_time:.1f}s | LLM: {llm_time:.1f}s | Total: {total_time:.1f}s*"


if __name__ == "__main__":
    question = "What is attention?"
    print(f"Question: {question}")
    print("-" * 60)
    print(generate_answer(question))