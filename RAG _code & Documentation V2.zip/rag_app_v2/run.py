"""
run.py — Start the RAG server.

Usage:
    python run.py

This starts the FastAPI server on port 8100.
Then connect Open WebUI to: http://127.0.0.1:8100/v1
"""
import uvicorn
from config import API_HOST, API_PORT

if __name__ == "__main__":
    print()
    print("=" * 60)
    print("  🚀  RAG SERVER STARTING")
    print("=" * 60)
    print(f"  URL:            http://127.0.0.1:{API_PORT}")
    print(f"  Open WebUI URL: http://127.0.0.1:{API_PORT}/v1")
    print(f"  Health check:   http://127.0.0.1:{API_PORT}/health")
    print(f"  Model name:     rag-model")
    print("=" * 60)
    print()

    uvicorn.run(
        "app.main:app",
        host=API_HOST,
        port=API_PORT,
        reload=False,
        log_level="info",
    )
