"""
ingest.py — Process PDFs into ChromaDB.

Usage:
    python ingest.py

This reads all PDFs from DOCS_PATH, extracts text + tables,
chunks them, embeds them with mxbai-embed-large, and stores
everything in ChromaDB.

Run this ONCE (or whenever you add new PDFs).
"""
import fitz  # PyMuPDF
import pdfplumber
from pathlib import Path
from tqdm import tqdm

from config import DOCS_PATH, CHUNK_SIZE, CHUNK_OVERLAP
from retrieval.embeddings import get_embedding
from retrieval.vectorstore import (
    get_text_collection,
    store_text_batch,
)


# ═══════════════════════════════════════════════════════════════
#  TEXT EXTRACTION
# ═══════════════════════════════════════════════════════════════

def extract_text_from_pdf(pdf_path: Path) -> list:
    """Extract text from each page of a PDF."""
    doc = fitz.open(str(pdf_path))
    pages = []
    for i, page in enumerate(doc):
        text = page.get_text("text").strip()
        if len(text) > 50:
            pages.append({
                "text": text,
                "page_num": i + 1,
                "source": pdf_path.name,
            })
    doc.close()
    return pages


# ═══════════════════════════════════════════════════════════════
#  CHUNKING
# ═══════════════════════════════════════════════════════════════

def chunk_page(page_data: dict) -> list:
    """Split a page into overlapping word-level chunks."""
    words = page_data["text"].split()
    if not words:
        return []

    step = CHUNK_SIZE - CHUNK_OVERLAP
    chunks = []
    for i in range(0, len(words), step):
        chunk_words = words[i : i + CHUNK_SIZE]
        if len(chunk_words) < 15:
            continue
        chunks.append({
            "content": " ".join(chunk_words),
            "page": page_data["page_num"],
            "source": page_data["source"],
            "type": "text",
        })
    return chunks


# ═══════════════════════════════════════════════════════════════
#  TABLE EXTRACTION
# ═══════════════════════════════════════════════════════════════

def extract_tables_from_pdf(pdf_path: Path) -> list:
    """Extract tables from a PDF using pdfplumber."""
    table_chunks = []
    try:
        with pdfplumber.open(str(pdf_path)) as pdf:
            for i, page in enumerate(pdf.pages):
                tables = page.extract_tables()
                for t_idx, table in enumerate(tables):
                    if not table or len(table) < 2:
                        continue
                    rows = []
                    for row in table:
                        cleaned = [str(c).strip() if c else "" for c in row]
                        rows.append(" | ".join(cleaned))
                    table_text = "\n".join(rows)
                    if len(table_text.strip()) < 20:
                        continue
                    content = f"[TABLE from page {i+1}]\n{table_text}"
                    table_chunks.append({
                        "content": content,
                        "page": i + 1,
                        "source": pdf_path.name,
                        "type": "table",
                    })
    except Exception as e:
        print(f"  ⚠️  Table extraction failed for {pdf_path.name}: {e}")
    return table_chunks


# ═══════════════════════════════════════════════════════════════
#  MAIN INGESTION
# ═══════════════════════════════════════════════════════════════

def ingest_all():
    """Process all PDFs and store embeddings in ChromaDB."""
    docs_folder = Path(DOCS_PATH)
    pdf_files = list(docs_folder.glob("*.pdf"))

    if not pdf_files:
        print(f"❌ No PDF files found in: {docs_folder.resolve()}")
        print("   Please add PDF files to that folder and re-run.")
        return

    print(f"\n📁 Found {len(pdf_files)} PDF(s):")
    for f in pdf_files:
        print(f"   • {f.name}")

    # ── Check what's already ingested ─────────────────────────
    coll = get_text_collection()
    existing = coll.get(limit=10000)
    ingested_sources = set()
    if existing["metadatas"]:
        ingested_sources = {m["source"] for m in existing["metadatas"]}

    new_pdfs = [f for f in pdf_files if f.name not in ingested_sources]
    if not new_pdfs:
        print(f"\n✅ All {len(pdf_files)} PDFs already ingested. Nothing to do.")
        print(f"   Already in ChromaDB: {ingested_sources}")
        return

    print(f"\n🆕 New PDFs to process: {len(new_pdfs)}")
    for f in new_pdfs:
        print(f"   → {f.name}")

    # ── Process each new PDF ──────────────────────────────────
    total_stored = 0

    for pdf_path in new_pdfs:
        print(f"\n{'─'*50}")
        print(f"Processing: {pdf_path.name}")

        # Extract text chunks
        pages = extract_text_from_pdf(pdf_path)
        text_chunks = []
        for page in pages:
            text_chunks.extend(chunk_page(page))
        print(f"  Text chunks: {len(text_chunks)}")

        # Extract table chunks
        table_chunks = extract_tables_from_pdf(pdf_path)
        print(f"  Table chunks: {len(table_chunks)}")

        # Combine and embed
        all_chunks = text_chunks + table_chunks
        BATCH = 20
        stored = 0

        for i in tqdm(range(0, len(all_chunks), BATCH), desc=f"  Embedding"):
            batch = all_chunks[i : i + BATCH]
            ids, embeddings, documents, metadatas = [], [], [], []

            for j, chunk in enumerate(batch):
                emb = get_embedding(chunk["content"])
                if emb is None:
                    continue
                chunk_id = f"{chunk['type']}_{chunk['source']}_{chunk['page']}_{i+j}"
                ids.append(chunk_id)
                embeddings.append(emb)
                documents.append(chunk["content"])
                metadatas.append({
                    "page": chunk["page"],
                    "type": chunk["type"],
                    "source": chunk["source"],
                })

            if ids:
                store_text_batch(ids, embeddings, documents, metadatas)
                stored += len(ids)

        print(f"  ✅ Stored: {stored} chunks")
        total_stored += stored

    # ── Summary ───────────────────────────────────────────────
    final_count = get_text_collection().count()
    print(f"\n{'═'*50}")
    print(f"🎉 Ingestion complete!")
    print(f"   New chunks added: {total_stored}")
    print(f"   Total in ChromaDB: {final_count}")
    print(f"{'═'*50}")


if __name__ == "__main__":
    ingest_all()
