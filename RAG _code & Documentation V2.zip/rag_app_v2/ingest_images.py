"""
ingest_images.py — Extract images from PDFs and store CLIP embeddings in ChromaDB.

Run ONCE after ingest.py:
    python ingest_images.py
"""
import os
import fitz
from pathlib import Path
from retrieval.embeddings import get_clip_image_embedding
from retrieval.vectorstore import get_image_collection
from config import DOCS_PATH, IMAGES_PATH


def ingest_images():
    docs_folder = Path(DOCS_PATH)
    pdf_files = list(docs_folder.glob("*.pdf"))

    if not pdf_files:
        print("❌ No PDFs found.")
        return

    print(f"Found {len(pdf_files)} PDF(s)")
    coll = get_image_collection()
    stored = 0

    for pdf_path in pdf_files:
        print(f"\nProcessing: {pdf_path.name}")
        doc = fitz.open(str(pdf_path))

        for page_num, page in enumerate(doc):
            images = page.get_images(full=True)
            for img_idx, img_info in enumerate(images):
                try:
                    base_image = doc.extract_image(img_info[0])
                    image_bytes = base_image["image"]

                    # Skip tiny images (icons, bullets)
                    if len(image_bytes) < 5 * 1024:
                        continue

                    # Save image to disk
                    img_filename = f"{pdf_path.stem}_page{page_num+1}_img{img_idx}.png"
                    img_path = os.path.join(IMAGES_PATH, img_filename)
                    with open(img_path, "wb") as f:
                        f.write(image_bytes)

                    # Get CLIP embedding
                    clip_emb = get_clip_image_embedding(img_path)

                    # Store in ChromaDB
                    content = f"[IMAGE from {pdf_path.name}, page {page_num+1}, image {img_idx+1}]"
                    img_id = f"img_{pdf_path.name}_{page_num+1}_{img_idx}"

                    coll.add(
                        ids=[img_id],
                        embeddings=[clip_emb],
                        documents=[content],
                        metadatas=[{
                            "page": page_num + 1,
                            "type": "image",
                            "source": pdf_path.name,
                            "image_path": img_path,
                        }],
                    )
                    stored += 1
                    print(f"  ✅ {img_filename}")

                except Exception as e:
                    pass

        doc.close()

    print(f"\n{'='*50}")
    print(f"🎉 Done! Stored {stored} images in ChromaDB.")
    print(f"   Total images now: {coll.count()}")
    print(f"{'='*50}")


if __name__ == "__main__":
    ingest_images()
