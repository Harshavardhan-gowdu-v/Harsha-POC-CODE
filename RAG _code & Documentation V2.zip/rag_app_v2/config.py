"""
config.py — All settings in one place.
"""
import os

# ═══════════════════════════════════════════════════════════════
#  PATHS — Change these to match YOUR machine
# ═══════════════════════════════════════════════════════════════

DOCS_PATH   = r"C:\Users\LENOVO\Desktop\rag_app_v2\data\Documets"
CHROMA_PATH = r"C:\Users\LENOVO\Desktop\rag_app_v2\data\chroma_db"
IMAGES_PATH = r"C:\Users\LENOVO\Desktop\rag_app_v2\data\images\extracted_images"

# ═══════════════════════════════════════════════════════════════
#  MODELS
# ═══════════════════════════════════════════════════════════════

EMBED_MODEL    = "mxbai-embed-large"
ANSWER_MODEL   = "llama3.2"                              # ← FAST on CPU
RERANKER_MODEL = "cross-encoder/ms-marco-MiniLM-L-6-v2"

# ═══════════════════════════════════════════════════════════════
#  RETRIEVAL
# ═══════════════════════════════════════════════════════════════

CHUNK_SIZE     = 300
CHUNK_OVERLAP  = 50
TOP_K_RETRIEVE = 10
TOP_K_RERANK   = 6
IMAGE_DISTANCE_THRESHOLD = 1.6   # CLIP images below this distance are included

# ═══════════════════════════════════════════════════════════════
#  SERVER
# ═══════════════════════════════════════════════════════════════

API_HOST = "0.0.0.0"
API_PORT = 8100

# ═══════════════════════════════════════════════════════════════
#  AUTO-CREATE FOLDERS
# ═══════════════════════════════════════════════════════════════

os.makedirs(DOCS_PATH, exist_ok=True)
os.makedirs(CHROMA_PATH, exist_ok=True)
os.makedirs(IMAGES_PATH, exist_ok=True)
