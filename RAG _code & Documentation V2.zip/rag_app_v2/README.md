# 🚀 Multimodal RAG App — Open WebUI + Ollama + ChromaDB

## Project Structure

```
rag_app/
├── app/
│   ├── __init__.py
│   ├── main.py          # FastAPI entrypoint (OpenAI-compatible API)
│   ├── llm.py           # Ollama generation (llama3.2)
│   └── prompts.py       # RAG prompt templates
│
├── retrieval/
│   ├── __init__.py
│   ├── embeddings.py    # Ollama embedding calls (mxbai-embed-large)
│   ├── vectorstore.py   # ChromaDB connection + storage
│   └── retriever.py     # Top-k retrieval + CrossEncoder reranking
│
├── data/
│   └── docs.txt         # Placeholder (PDFs go in DOCS_PATH)
│
├── config.py            # All settings in one place
├── ingest.py            # Process PDFs → ChromaDB (run once)
├── run.py               # Start the FastAPI server
├── requirements.txt     # Python dependencies
└── README.md            # This file
```

---

## How It Works

```
You type in Open WebUI → POST /v1/chat/completions
    → app/main.py receives the message
    → app/llm.py calls retrieval/retriever.py
    → retriever.py embeds query via retrieval/embeddings.py
    → retriever.py searches ChromaDB via retrieval/vectorstore.py
    → retriever.py reranks results with CrossEncoder
    → app/llm.py builds prompt from app/prompts.py
    → app/llm.py calls Ollama llama3.2
    → Answer streams back to Open WebUI
```

---

## Step-by-Step Setup

### STEP 1: Install Ollama

Download from https://ollama.com and install it.

### STEP 2: Pull Models

Open a terminal:
```
ollama serve
```

Open ANOTHER terminal:
```
ollama pull mxbai-embed-large
ollama pull llama3.2
ollama list
```

Both models should appear in the list. Keep `ollama serve` running.

### STEP 3: Open config.py and Set Your Paths

Edit `config.py` — change DOCS_PATH to your PDF folder:
```python
DOCS_PATH  = r"C:\Users\LENOVO\Desktop\Multimodal AI Store\Data\Documets"
CHROMA_PATH = r"C:\Users\LENOVO\Desktop\Multimodal AI Store\Data\chroma_db"
```

### STEP 4: Put PDFs in DOCS_PATH

Copy your PDF files into the folder you set in DOCS_PATH.

### STEP 5: Install Python Dependencies

```
cd rag_app
pip install -r requirements.txt
```

### STEP 6: Ingest PDFs into ChromaDB (run once)

```
python ingest.py
```

This reads all PDFs, chunks them, embeds them, and stores in ChromaDB.
Takes a few minutes. You only need to run this once.

Output should look like:
```
📁 Found 2 PDF(s):
   • Attention all you need.pdf
   • Sample.pdf
Processing: Attention all you need.pdf
  Text chunks: 29
  Table chunks: 9
  ✅ Stored: 38 chunks
🎉 Ingestion complete!
```

### STEP 7: Start the RAG Server

```
python run.py
```

You should see:
```
🚀  RAG SERVER STARTING
  URL:            http://127.0.0.1:8100
  Open WebUI URL: http://127.0.0.1:8100/v1
  Model name:     rag-model
```

### STEP 8: Test the Server

Open a browser and go to:
```
http://127.0.0.1:8100/health
```

You should see:
```json
{"status": "ok", "text_chunks": 47, "image_chunks": 4}
```

### STEP 9: Install Open WebUI

Open a NEW terminal:
```
pip install open-webui
open-webui serve
```

Go to http://localhost:8080 in your browser.

### STEP 10: Create Open WebUI Account

First time: Sign up with any name/email/password.
The first account becomes admin automatically.
Everything is stored locally — nothing goes to any cloud.

### STEP 11: Connect to Your RAG Server

1. Click your user icon → Settings → Admin Settings → Connections
2. Under OpenAI API, click + Add Connection
3. Fill in:
   - API Base URL: `http://127.0.0.1:8100/v1`
   - API Key: `rag-key` (any string works)
4. Click Verify Connection → should turn green
5. Save

### STEP 12: Chat!

1. Click New Chat
2. Select model: **rag-model**
3. Type a question about your PDFs
4. Hit Enter
5. Answer appears with page citations!

---

## Which Terminals to Keep Open

You need THREE terminals running:

| Terminal | Command | Keep running? |
|----------|---------|---------------|
| 1 | `ollama serve` | Always |
| 2 | `python run.py` | Always (in rag_app folder) |
| 3 | `open-webui serve` | Always |

---

## Adding New PDFs

1. Drop new PDFs into your DOCS_PATH folder
2. Run: `python ingest.py`
3. It only processes new PDFs (skips already-ingested ones)

---

## Testing Each Layer

If something breaks, test bottom-up:

| Test | Command / URL | What to expect |
|------|---------------|----------------|
| Ollama alive? | `curl http://localhost:11434/api/tags` | List of models |
| Embeddings work? | `python retrieval/embeddings.py` | "✅ Embedding OK — 1024 dimensions" |
| ChromaDB has data? | `python retrieval/vectorstore.py` | Chunk counts > 0 |
| Retrieval works? | `python retrieval/retriever.py` | Found chunks listed |
| LLM answers? | `python app/llm.py` | Answer with citations |
| Server running? | http://127.0.0.1:8100/health | {"status": "ok"} |
| Models visible? | http://127.0.0.1:8100/v1/models | rag-model listed |
