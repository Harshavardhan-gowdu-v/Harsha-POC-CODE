"""
retrieval/embeddings.py — Ollama + CLIP embedding calls.

Two embedding types:
  1. mxbai-embed-large (1024-dim) — for text/table search via Ollama
  2. CLIP ViT-B/32 (512-dim)     — for image search (text query → matching image)
"""
import ollama
from config import EMBED_MODEL

import torch
import open_clip
import warnings
warnings.filterwarnings("ignore")


# ═══════════════════════════════════════════════════════════════
#  TEXT EMBEDDING (mxbai via Ollama)
# ═══════════════════════════════════════════════════════════════

def get_embedding(text: str) -> list:
    """Generate 1024-dim embedding for text search."""
    text = str(text).strip()[:1000]
    try:
        response = ollama.embed(model=EMBED_MODEL, input=text, keep_alive=0)
        return response["embeddings"][0]
    except Exception as e:
        print(f"[embeddings] mxbai ERROR: {e}")
        return None


# ═══════════════════════════════════════════════════════════════
#  CLIP EMBEDDING (for image search)
# ═══════════════════════════════════════════════════════════════

print("[embeddings] Loading CLIP ViT-B/32...")
_clip_model, _, _clip_preprocess = open_clip.create_model_and_transforms(
    "ViT-B-32", pretrained="openai"
)
_clip_tokenizer = open_clip.get_tokenizer("ViT-B-32")
_clip_model.eval()
_DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
_clip_model = _clip_model.to(_DEVICE)
print(f"[embeddings] ✅ CLIP loaded on {_DEVICE}")


def get_clip_text_embedding(text: str) -> list:
    """
    Generate 512-dim CLIP embedding from text.
    Used at QUERY TIME to search the images collection.

    CLIP maps text and images into the SAME space:
      embed("bar chart") ≈ embed(picture_of_bar_chart)
    """
    tokens = _clip_tokenizer([text[:77]]).to(_DEVICE)
    with torch.no_grad():
        emb = _clip_model.encode_text(tokens)
        emb = emb / emb.norm(dim=-1, keepdim=True)
    return emb[0].cpu().numpy().tolist()


def get_clip_image_embedding(image_path: str) -> list:
    """
    Generate 512-dim CLIP embedding from an image file.
    Used during INGESTION to embed extracted PDF images.
    """
    from PIL import Image
    image = Image.open(image_path).convert("RGB")
    tensor = _clip_preprocess(image).unsqueeze(0).to(_DEVICE)
    with torch.no_grad():
        emb = _clip_model.encode_image(tensor)
        emb = emb / emb.norm(dim=-1, keepdim=True)
    return emb[0].cpu().numpy().tolist()


# ═══════════════════════════════════════════════════════════════
#  TEST
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    emb = get_embedding("test sentence")
    print(f"✅ mxbai: {len(emb)} dims" if emb else "❌ mxbai FAILED")

    clip_emb = get_clip_text_embedding("a diagram")
    print(f"✅ CLIP:  {len(clip_emb)} dims" if clip_emb else "❌ CLIP FAILED")
