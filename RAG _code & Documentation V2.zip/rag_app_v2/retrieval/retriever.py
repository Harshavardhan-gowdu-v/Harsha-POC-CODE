"""
retrieval/retriever.py — Top-k retrieval + reranking + IMAGE search.

Three-stage retrieval:
  1. ChromaDB text search  → top 8 text/table candidates
  2. CrossEncoder rerank   → top 5 text/table chunks
  3. CLIP image search     → top 2 matching images (cross-modal)
"""
from sentence_transformers import CrossEncoder
from config import RERANKER_MODEL, TOP_K_RETRIEVE, TOP_K_RERANK, IMAGE_DISTANCE_THRESHOLD
from retrieval.embeddings import get_embedding, get_clip_text_embedding
from retrieval.vectorstore import query_text, query_images

import warnings
warnings.filterwarnings("ignore")


# ═══════════════════════════════════════════════════════════════
#  LOAD RERANKER (once)
# ═══════════════════════════════════════════════════════════════

print(f"[retriever] Loading reranker: {RERANKER_MODEL}")
_reranker = CrossEncoder(RERANKER_MODEL)
print("[retriever] ✅ Reranker ready")


# ═══════════════════════════════════════════════════════════════
#  TEXT RETRIEVAL
# ═══════════════════════════════════════════════════════════════

def retrieve_text(query: str, top_k: int = TOP_K_RETRIEVE) -> list:
    """Stage 1: Fast vector search over text_and_tables."""
    emb = get_embedding(query)
    if emb is None:
        return []

    results = query_text(emb, n_results=top_k)

    docs = []
    for doc, meta in zip(results["documents"][0], results["metadatas"][0]):
        docs.append({
            "content": doc,
            "page": meta.get("page", 0),
            "type": meta.get("type", "text"),
            "source": meta.get("source", ""),
        })
    return docs


# ═══════════════════════════════════════════════════════════════
#  IMAGE RETRIEVAL (CLIP cross-modal)
# ═══════════════════════════════════════════════════════════════

def retrieve_images(query: str, top_k: int = 2) -> list:
    """
    CLIP cross-modal image search.
    CLIP automatically matches query text to relevant images.
    No keyword filter needed — CLIP understands meaning.
    
    Example: "What is attention?" → CLIP finds attention diagrams
    because CLIP was trained to match text and images by meaning.
    """
    clip_emb = get_clip_text_embedding(query)
    results = query_images(clip_emb, n_results=top_k)

    images = []
    for doc, meta, dist in zip(
        results["documents"][0],
        results["metadatas"][0],
        results["distances"][0],
    ):
        print(f"  [IMAGE] {meta.get('source','')} p.{meta.get('page',0)} dist={dist:.3f}")
        if dist < IMAGE_DISTANCE_THRESHOLD:
            images.append({
                "content": doc,
                "page": meta.get("page", 0),
                "type": "image",
                "source": meta.get("source", ""),
                "image_path": meta.get("image_path", ""),
                "distance": dist,
            })
    return images[:2]
    


# ═══════════════════════════════════════════════════════════════
#  RERANK TEXT CHUNKS
# ═══════════════════════════════════════════════════════════════

def rerank(query: str, docs: list, top_k: int = TOP_K_RERANK) -> list:
    """Stage 2: CrossEncoder reranking for text/table chunks."""
    if not docs:
        return []

    pairs = [[query, d["content"]] for d in docs]
    scores = _reranker.predict(pairs)

    ranked = sorted(zip(docs, scores), key=lambda x: x[1], reverse=True)
    return [doc for doc, _ in ranked[:top_k]]


# ═══════════════════════════════════════════════════════════════
#  FULL PIPELINE (TEXT + IMAGES)
# ═══════════════════════════════════════════════════════════════

def full_retrieve(query: str) -> tuple:
    """
    Complete retrieval pipeline:
      1. Text: query → embed → ChromaDB → rerank → top chunks
      2. Images: query → CLIP embed → ChromaDB images → matched images

    Returns:
        (text_chunks, image_chunks)
    """
    # Text retrieval + reranking
    candidates = retrieve_text(query, top_k=TOP_K_RETRIEVE)
    top_text = rerank(query, candidates, top_k=TOP_K_RERANK)

    # Image retrieval (CLIP cross-modal)
    top_images = retrieve_images(query, top_k=2)

    return top_text, top_images


if __name__ == "__main__":
    test_q = "What is this document about?"
    text_chunks, image_chunks = full_retrieve(test_q)
    print(f"\nQuery: {test_q}")
    print(f"Text chunks: {len(text_chunks)}")
    for r in text_chunks:
        print(f"  → [{r['type']}] {r['source']}, Page {r['page']}")
    print(f"Image chunks: {len(image_chunks)}")
    for img in image_chunks:
        print(f"  → [IMAGE] {img['source']}, Page {img['page']}, dist={img['distance']:.3f}")
