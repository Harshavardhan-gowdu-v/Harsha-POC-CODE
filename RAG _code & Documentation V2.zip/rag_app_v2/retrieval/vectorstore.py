"""
retrieval/vectorstore.py — ChromaDB connection + storage.
Manages the persistent vector database with two collections:
  - text_and_tables  (1024-dim mxbai embeddings)
  - images           (512-dim CLIP embeddings)
"""
import chromadb
from config import CHROMA_PATH


# ═══════════════════════════════════════════════════════════════
#  CONNECT TO CHROMADB (persistent on disk)
# ═══════════════════════════════════════════════════════════════

_client = None
_text_collection = None
_image_collection = None


def get_client():
    """Get or create the ChromaDB client (singleton)."""
    global _client
    if _client is None:
        print(f"[vectorstore] Connecting to ChromaDB at: {CHROMA_PATH}")
        _client = chromadb.PersistentClient(path=CHROMA_PATH)
    return _client


def get_text_collection():
    """Get the text_and_tables collection."""
    global _text_collection
    if _text_collection is None:
        client = get_client()
        _text_collection = client.get_or_create_collection("text_and_tables")
        print(f"[vectorstore] text_and_tables: {_text_collection.count()} chunks")
    return _text_collection


def get_image_collection():
    """Get the images collection."""
    global _image_collection
    if _image_collection is None:
        client = get_client()
        _image_collection = client.get_or_create_collection("images")
        print(f"[vectorstore] images: {_image_collection.count()} chunks")
    return _image_collection


# ═══════════════════════════════════════════════════════════════
#  STORAGE HELPERS (used during ingestion)
# ═══════════════════════════════════════════════════════════════

def store_text_chunk(chunk_id: str, embedding: list, content: str, metadata: dict):
    """Store a single text/table chunk with its embedding."""
    coll = get_text_collection()
    coll.add(
        ids=[chunk_id],
        embeddings=[embedding],
        documents=[content],
        metadatas=[metadata],
    )


def store_text_batch(ids: list, embeddings: list, documents: list, metadatas: list):
    """Store a batch of text/table chunks."""
    coll = get_text_collection()
    coll.add(ids=ids, embeddings=embeddings, documents=documents, metadatas=metadatas)


def store_image_chunk(chunk_id: str, embedding: list, content: str, metadata: dict):
    """Store a single image chunk with its CLIP embedding."""
    coll = get_image_collection()
    coll.add(
        ids=[chunk_id],
        embeddings=[embedding],
        documents=[content],
        metadatas=[metadata],
    )


# ═══════════════════════════════════════════════════════════════
#  QUERY HELPERS (used during retrieval)
# ═══════════════════════════════════════════════════════════════

def query_text(embedding: list, n_results: int = 8) -> dict:
    """Search text_and_tables collection by embedding vector."""
    coll = get_text_collection()
    count = coll.count()
    if count == 0:
        return {"documents": [[]], "metadatas": [[]], "distances": [[]]}
    return coll.query(
        query_embeddings=[embedding],
        n_results=min(n_results, count),
    )


def query_images(embedding: list, n_results: int = 2) -> dict:
    """Search images collection by CLIP embedding vector."""
    coll = get_image_collection()
    count = coll.count()
    if count == 0:
        return {"documents": [[]], "metadatas": [[]], "distances": [[]]}
    return coll.query(
        query_embeddings=[embedding],
        n_results=min(n_results, count),
    )


def get_stats() -> dict:
    """Return chunk counts for status dashboard."""
    return {
        "text_chunks": get_text_collection().count(),
        "image_chunks": get_image_collection().count(),
    }


if __name__ == "__main__":
    stats = get_stats()
    print(f"ChromaDB Status:")
    print(f"  text_and_tables: {stats['text_chunks']} chunks")
    print(f"  images:          {stats['image_chunks']} chunks")
